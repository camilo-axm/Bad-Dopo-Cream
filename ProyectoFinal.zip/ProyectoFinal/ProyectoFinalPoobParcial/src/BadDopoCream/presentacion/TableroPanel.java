package BadDopoCream.presentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import BadDopoCream.dominio.Juego;
import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.tablero.Celda;
import BadDopoCream.dominio.tablero.TipoCelda;
import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.controladores.Controlador;
import BadDopoCream.dominio.componentes.obstaculos.Fogata;
import BadDopoCream.dominio.componentes.obstaculos.BaldosaCaliente;

/**
 * Panel donde se muestra el tablero del juego Bad Dopo Cream.
 * Aquí puedes agregar botones, textos, imágenes o dibujar con Shapes.
 * 
 * @author Camilo Aguirre
 * @version 02/12/2025
 */
public class TableroPanel extends JPanel {

    /** Referencia a la lógica del juego */
    private Juego juego;

    /** Modo de juego activo */
    private String modoJuego;

    /** Controlador para manejar eventos */
    private Controlador controlador;

    /** Timer para actualizar el panel dinámicamente */
    private Timer timer;
    
    /** Referencia a la GUI principal para obtener imágenes */
    private BadDopoCreamGUI gui;
    
    // Imágenes del tablero (las imágenes de frutas, helados, enemigos y obstáculos se cargan en sus respectivas clases)
    private Image imgFondoTablero;
    private Image imgBloqueHielo;

    /**
     * Constructor del panel del tablero.
     * @param juego instancia del juego
     * @param modoJuego modo de juego seleccionado
     * @param controlador instancia del controlador para manejar eventos
     * @param gui referencia a BadDopoCreamGUI para obtener imágenes
     */
    public TableroPanel(Juego juego, String modoJuego, Controlador controlador, BadDopoCreamGUI gui) {
        this.juego = juego;
        this.modoJuego = modoJuego;
        this.controlador = controlador;
        this.gui = gui;

        setLayout(null);  // Usamos layout nulo para poder posicionar los componentes manualmente
        
        // Cargar imágenes necesarias personalizadas para el tablero
        cargarImagenes();
        
        // Botón para pausar el juego
        JButton botonPausar = new JButton("Pausar");
        botonPausar.setBounds(800, 11, 75, 25);
        botonPausar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controlador.manejarEvento("PAUSAR_JUEGO");
            }
        });
        add(botonPausar);

        // Botón para reiniciar el juego
        JButton botonReiniciar= new JButton("Reiniciar");
        botonReiniciar.setBounds(800, 40, 75, 25);
        botonReiniciar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controlador.manejarEvento("REINICIAR_JUEGO");
            }
        });
        add(botonReiniciar);
        
        JButton botonVolver = new JButton("Volver");
        botonVolver.setBounds(800, 127, 75, 25);
        botonVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int opcion = JOptionPane.showConfirmDialog(
                    TableroPanel.this,
                    "¿Estás seguro de que deseas volver al menú principal?",
                    "Confirmar",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
                );
                if (opcion == JOptionPane.YES_OPTION) {
                    controlador.manejarEvento("VOLVER_INICIO");
                }
            }
        });
        add(botonVolver);
        
        // No agregamos un panel gris que tape el dibujo
        // El tablero se dibujará directamente en paintComponent
        // La información (tiempo, puntaje, frutas) se dibuja en paintComponent
        
        // Timer para actualizar el panel
        timer = new Timer(1000 / 60, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                repaint();
            }
        }); // 60 FPS
        timer.start();
    }
    
    /**
     * Carga las imágenes del tablero.
     * 
     * Nota: Las imágenes de frutas y helados se cargan automáticamente
     * en sus respectivas clases (Fruta.java y Helado.java).
     * 
     * Este método solo carga:
     * - Fondo del tablero (que incluye el iglú dibujado)
     * - Bloques de hielo
     * 
     * El iglú NO se dibuja porque ya está en la imagen de fondo.
     * Las celdas tipo IGLU solo bloquean el movimiento.
     */
    private void cargarImagenes() {
            try {
                java.net.URL url;
                
                // Carga el fondo del tablero (incluye el iglú dibujado)
                url = getClass().getResource("/BadDopoCream/presentacion/recursos/Tablerooo.jpeg");
                if (url != null) {
                    imgFondoTablero = new ImageIcon(url).getImage();
                } else {
                    System.err.println("Imagen de fondo no encontrada: Tablerooo.jpeg");
                }

                // Carga el bloque de hielo
                url = getClass().getResource("/BadDopoCream/presentacion/recursos/bloqueHielo.jpeg");
                if (url != null) {
                    imgBloqueHielo = new ImageIcon(url).getImage();
                } else {
                    System.err.println("Imagen no encontrada: bloqueHielo.jpeg");
                }

            } catch (Exception e) {
                System.err.println("Error cargando imágenes del tablero: " + e.getMessage());
                e.printStackTrace();
            }
    }

    /**
     * Método principal que dibuja TODO el juego.
     * Llama a otros métodos más pequeños para mantener el código organizado.
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        
        // Verificar que el juego y tablero existan
        if (!verificarJuegoValido(g2d)) {
            return; // Si hay error, no seguimos dibujando
        }
        
        // Obtener el tablero
        Tablero tablero = juego.getTablero();
        
        // Configurar las medidas del tablero
        int celdaSize = 40;  // Cada celda mide 40x40 pixels
        int offsetX = 120;   // Margen izquierdo
        int offsetY = 40;    // Margen superior
        
        // Dibujar el fondo del tablero
        dibujarFondoDelTablero(g2d, tablero, celdaSize, offsetX, offsetY);
        
        // Dibujar los bloques de hielo
        dibujarBloquesDeHielo(g2d, tablero, celdaSize, offsetX, offsetY);
        
        // Dibujar obstáculos (fogatas y baldosas calientes)
        dibujarObstaculosDelJuego(g2d, tablero, celdaSize, offsetX, offsetY);
        
        // Dibujar las frutas
        dibujarTodasLasFrutas(g2d, tablero, celdaSize, offsetX, offsetY);
        
        // Dibujar los enemigos
        dibujarTodosLosEnemigos(g2d, tablero, celdaSize, offsetX, offsetY);
        
        // Dibujar los helados (jugadores)
        dibujarLosHelados(g2d, tablero, celdaSize, offsetX, offsetY);
        
        // Dibujar información (puntaje, tiempo, etc.)
        dibujarInformacionDelJuego(g2d, tablero);
    }
    
    /**
     * Verifica que el juego esté listo para dibujar.
     * Retorna true si todo está bien, false si hay error.
     */
    private boolean verificarJuegoValido(Graphics2D g2d) {
        if (juego == null) {
            g2d.setColor(Color.RED);
            g2d.drawString("Error juego es null", 300, 300);
            return false;
        }
        
        Tablero tablero = juego.getTablero();
        if (tablero == null) {
            g2d.setColor(Color.RED);
            g2d.drawString("Esperando tablero...", 300, 300);
            return false;
        }
        
        if (tablero.getMatriz() == null) {
            g2d.setColor(Color.RED);
            g2d.drawString("Error matriz es null", 300, 300);
            return false;
        }
        
        return true; // Todo está bien
    }
    
    /**
     * Dibuja la imagen de fondo del tablero.
     */
    private void dibujarFondoDelTablero(Graphics2D g2d, Tablero tablero, int celdaSize, int offsetX, int offsetY) {
        int anchoTablero = tablero.getColumnas() * celdaSize;  // 15 columnas * 40 = 600
        int altoTablero = tablero.getFilas() * celdaSize;      // 12 filas * 40 = 480
        
        if (imgFondoTablero != null) {
            // Dibujar la imagen de fondo
            g2d.drawImage(imgFondoTablero, offsetX, offsetY, anchoTablero, altoTablero, this);
        } else {
            // Si no hay imagen, dibujar un fondo gris
            g2d.setColor(new Color(192, 192, 192));
            g2d.fillRect(offsetX, offsetY, anchoTablero, altoTablero);
        }
    }
    
    /**
     * Dibuja los bloques de hielo en el tablero.
     */
    private void dibujarBloquesDeHielo(Graphics2D g2d, Tablero tablero, int celdaSize, int offsetX, int offsetY) {
        Celda[][] matriz = tablero.getMatriz();
        
        // Recorrer todas las celdas del tablero
        for (int fila = 0; fila < tablero.getFilas(); fila++) {
            for (int col = 0; col < tablero.getColumnas(); col++) {
                Celda celda = matriz[fila][col];
                
                // Solo dibujar si es un bloque de hielo
                if (celda.getTipo().getTipo() == TipoCelda.BLOQUE_HIELO) {
                    int x = offsetX + col * celdaSize;
                    int y = offsetY + fila * celdaSize;
                    
                    if (imgBloqueHielo != null) {
                        g2d.drawImage(imgBloqueHielo, x, y, celdaSize, celdaSize, this);
                    } else {
                        // Dibujar con colores
                        g2d.setColor(new Color(150, 220, 255));
                        g2d.fillRect(x, y, celdaSize, celdaSize);
                        g2d.setColor(Color.WHITE);
                        g2d.drawRect(x + 2, y + 2, celdaSize - 4, celdaSize - 4);
                    }
                }
            }
        }
    }
    
    /**
     * Dibuja los obstáculos (fogatas y baldosas calientes).
     */
    private void dibujarObstaculosDelJuego(Graphics2D g2d, Tablero tablero, int celdaSize, int offsetX, int offsetY) {
        // Dibujar fogatas (fuego que da) daño)
        if (tablero.getFogatas() != null) {
            for (Fogata fogata : tablero.getFogatas()) {
                Posicion pos = fogata.getPosicion();
                int x = offsetX + pos.getX() * celdaSize;
                int y = offsetY + pos.getY() * celdaSize;
                
                Image imgFogata = gui.getImagen("Fogata");
                if (imgFogata != null) {
                    g2d.drawImage(imgFogata, x, y, celdaSize, celdaSize, this);
                } else {
                    // Rectángulo naranja/rojo
                    g2d.setColor(new Color(255, 69, 0));
                    g2d.fillRect(x, y, celdaSize, celdaSize);
                }
            }
        }
        
        // Dibujar baldosas calientes (pisos calientes)
        if (tablero.getBaldosasCalientes() != null) {
            for (BaldosaCaliente baldosa : tablero.getBaldosasCalientes()) {
                Posicion pos = baldosa.getPosicion();
                int x = offsetX + pos.getX() * celdaSize;
                int y = offsetY + pos.getY() * celdaSize;
                
                Image imgBaldosa = gui.getImagen("BaldosaCaliente");
                if (imgBaldosa != null) {
                    g2d.drawImage(imgBaldosa, x, y, celdaSize, celdaSize, this);
                } else {
                    // Rectángulo naranja claro
                    g2d.setColor(new Color(255, 140, 0));
                    g2d.fillRect(x, y, celdaSize, celdaSize);
                }
            }
        }
    }
    
    /**
     * Dibuja todas las frutas del juego.
     */
    private void dibujarTodasLasFrutas(Graphics2D g2d, Tablero tablero, int celdaSize, int offsetX, int offsetY) {
        if (tablero.getFrutas() == null) return;
        
        for (BadDopoCream.dominio.componentes.frutas.Fruta fruta : tablero.getFrutas()) {
            if (!fruta.isActiva()) continue; // Solo dibujar frutas activas
            
            Posicion pos = fruta.getPosicion();
            int x = offsetX + pos.getX() * celdaSize;
            int y = offsetY + pos.getY() * celdaSize;
            
            // Obtener el tipo de fruta (Uva, Platano, etc.)
            String tipoFruta = fruta.getClass().getSimpleName();
            Image imgFruta = gui.getImagen(tipoFruta);
            
            if (imgFruta != null) {
                g2d.drawImage(imgFruta, x, y, celdaSize, celdaSize, this);
            } else {
                // Dibujar círculos de colores según el tipo
                dibujarFrutaConColor(g2d, tipoFruta, x, y, celdaSize);
            }
        }
    }
    
    /**
     * Dibuja una fruta usando colores cuando no hay imagen.
     */
    private void dibujarFrutaConColor(Graphics2D g2d, String tipoFruta, int x, int y, int tamaño) {
        switch (tipoFruta) {
            case "Uva":
                g2d.setColor(new Color(148, 0, 211)); // Morado
                break;
            case "Platano":
                g2d.setColor(new Color(255, 255, 0)); // Amarillo
                break;
            case "Pina":
                g2d.setColor(new Color(255, 200, 0)); // Naranja-amarillo
                break;
            case "Cereza":
                g2d.setColor(new Color(220, 20, 60)); // Rojo
                break;
            case "Cactus":
                g2d.setColor(new Color(0, 128, 0)); // Verde
                break;
            default:
                g2d.setColor(Color.GREEN); // Color por defecto
        }
        g2d.fillOval(x + 8, y + 8, tamaño - 16, tamaño - 16);
    }
    
    /**
     * Dibuja todos los enemigos del juego.
     */
    private void dibujarTodosLosEnemigos(Graphics2D g2d, Tablero tablero, int celdaSize, int offsetX, int offsetY) {
        if (tablero.getEnemigos() == null) return;
        
        for (BadDopoCream.dominio.componentes.enemigos.Enemigo enemigo : tablero.getEnemigos()) {
            if (!enemigo.isActiva()) continue; // Solo enemigos activos
            
            Posicion pos = enemigo.getPosicion();
            int x = offsetX + pos.getX() * celdaSize;
            int y = offsetY + pos.getY() * celdaSize;
            
            // Obtener el tipo de enemigo (Troll, Maceta, etc.)
            String tipoEnemigo = enemigo.getClass().getSimpleName();
            Image imgEnemigo = gui.getImagen(tipoEnemigo);
            
            if (imgEnemigo != null) {
                g2d.drawImage(imgEnemigo, x, y, celdaSize, celdaSize, this);
            } else {
                // Dibujar cuadrados de colores
                dibujarEnemigoConColor(g2d, tipoEnemigo, x, y, celdaSize);
            }
        }
    }
    
    /**
     * Dibuja un enemigo usando colores cuando no hay imagen.
     */
    private void dibujarEnemigoConColor(Graphics2D g2d, String tipoEnemigo, int x, int y, int tamaño) {
        switch (tipoEnemigo) {
            case "Troll":
                g2d.setColor(new Color(0, 128, 0)); // Verde
                break;
            case "Maceta":
                g2d.setColor(new Color(139, 69, 19)); // Marrón
                break;
            case "CalamarNaranja":
                g2d.setColor(new Color(255, 140, 0)); // Naranja
                break;
            case "Narval":
                g2d.setColor(new Color(100, 149, 237)); // Azul
                break;
            default:
                g2d.setColor(Color.RED); // Color por defecto
        }
        g2d.fillRect(x + 5, y + 5, tamaño - 10, tamaño - 10);
        g2d.setColor(Color.BLACK);
        g2d.drawRect(x + 5, y + 5, tamaño - 10, tamaño - 10);
    }
    
    /**
     * Dibuja los helados (jugadores).
     */
    private void dibujarLosHelados(Graphics2D g2d, Tablero tablero, int celdaSize, int offsetX, int offsetY) {
        // Dibujar jugador 1
        if (tablero.getHelado() != null) {
            dibujarUnHelado(g2d, tablero.getHelado(), celdaSize, offsetX, offsetY, false);
        }
        
        // Dibujar jugador 2 (si existe)
        if (tablero.getHelado2() != null) {
            dibujarUnHelado(g2d, tablero.getHelado2(), celdaSize, offsetX, offsetY, true);
        }
    }
    
    /**
     * Dibuja un helado individual.
     */
    private void dibujarUnHelado(Graphics2D g2d, BadDopoCream.dominio.componentes.helados.Helado helado, 
                                 int celdaSize, int offsetX, int offsetY, boolean esJugador2) {
        Posicion pos = helado.getPosicion();
        int x = offsetX + pos.getX() * celdaSize;
        int y = offsetY + pos.getY() * celdaSize;
        
        // Obtener la imagen del helado (Vainilla, Chocolate o Fresa)
        String tipoHelado = helado.getClass().getSimpleName();
        Image imgHelado = gui.getImagen(tipoHelado);
        
        if (imgHelado != null) {
            g2d.drawImage(imgHelado, x, y, celdaSize, celdaSize, this);
        } else {
            // Círculo con color según el tipo
            dibujarHeladoConColor(g2d, tipoHelado, x, y, celdaSize);
        }
    }
    
    /**
     * Dibuja un helado usando colores cuando no hay imagen.
     */
    private void dibujarHeladoConColor(Graphics2D g2d, String tipoHelado, int x, int y, int tamaño) {
        switch (tipoHelado) {
            case "HeladoVainilla":
                g2d.setColor(new Color(255, 248, 220)); // Beige claro
                break;
            case "HeladoChocolate":
                g2d.setColor(new Color(139, 69, 19)); // Marrón
                break;
            case "HeladoFresa":
                g2d.setColor(new Color(255, 182, 193)); // Rosa
                break;
            default:
                g2d.setColor(Color.WHITE); // Blanco por defecto
        }
        g2d.fillOval(x + 6, y + 6, tamaño - 12, tamaño - 12);
        g2d.setColor(Color.BLACK);
        g2d.drawOval(x + 6, y + 6, tamaño - 12, tamaño - 12);
    }
    
    /**
     * Dibuja la información del juego (puntaje, tiempo, etc.).
     */
    private void dibujarInformacionDelJuego(Graphics2D g2d, Tablero tablero) {
        g2d.setColor(Color.BLACK);
        g2d.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 14));
        
        String modo = juego.getModoJuego();
        boolean dosJugadores = tablero.getHelado2() != null;
        
        if (dosJugadores) {
            // Información para 2 jugadores
            dibujarInfoDosJugadores(g2d, modo);
        } else {
            // Información para 1 jugador
            dibujarInfoUnJugador(g2d);
        }
    }
    
    /**
     * Dibuja info para modo de 2 jugadores.
     */
    private void dibujarInfoDosJugadores(Graphics2D g2d, String modo) {
        // Jugador 1
        g2d.setColor(Color.BLACK);
        String estadoJ1 = juego.isHelado1Vivo() ? "J1: " + juego.getPuntaje() : "J1: MUERTO";
        g2d.drawString(estadoJ1, 140, 28);
        
        // Jugador 2
        g2d.setColor(Color.BLACK);
        String estadoJ2 = juego.isHelado2Vivo() ? "J2: " + juego.getPuntaje2() : "J2: MUERTO";
        g2d.drawString(estadoJ2, 230, 28);
        
        // Tiempo
        g2d.setColor(Color.BLACK);
        if (juego.getTemporizador() != null) {
            g2d.drawString(juego.getTemporizador().getTiempoFormateado(), 400, 28);
        }
        
        // Frutas restantes
        g2d.drawString("Frutas: " + juego.getFrutasRestantes(), 560, 28);
        
    }
    
    /**
     * Dibuja info para modo de 1 jugador.
     */
    private void dibujarInfoUnJugador(Graphics2D g2d) {
        g2d.drawString("Puntos: " + juego.getPuntaje(), 190, 28);
        
        if (juego.getTemporizador() != null) {
            g2d.drawString(juego.getTemporizador().getTiempoFormateado(), 460, 28);
        }
        
        g2d.drawString("Frutas: " + juego.getFrutasRestantes(), 320, 28);
    }

}
