package BadDopoCream.presentacion;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import BadDopoCream.dominio.Juego;
import BadDopoCream.controladores.Controlador;
import java.net.URL;

/**
 * BadDopoCreamGUI - Clase principal de la interfaz gráfica integrada con navegación
 * Incluye: panelInicio, panelModos, panelSeleccionModo, panelSeleccionJugadores,
 * panelSeleccionUnJugadorHelados, panelSelecciondosJugadorHelados, panelSeleccionNiveles,
 * panelJuego (TableroPanel).
 * Flujo:
 *  Botón Jugar, luego panelSeleccionModo, luego panelSeleccionJugadores (1 jugador / 2 jugadores), luego
 *  Selección helado(s) luego, panelSeleccionNiveles y por ultimo iniciar juego 
 */
public class BadDopoCreamGUI extends JFrame {

    // Paneles principales
    private JPanel panelInicio;
    private JPanel panelModos;
    private JPanel panelSeleccionModo;
    private JPanel panelSeleccionNiveles;
    private JPanel panelSeleccionJugadores;
    private JPanel panelSeleccionUnJugadorHelados;
    private JPanel panelSelecciondosJugadorHelados;
    private JPanel panelSeleccionPerfilesMaquina; // Para PvsM y MvsM

    // Panel del juego (dibujo)
    private TableroPanel panelJuego;

    // Modelo y controlador
    private Juego juego;
    private Controlador controlador;

    // Estado / selección
    private String modoJuegoActual;
    private int nivelSeleccionado = 1;
    private String heladoJugador1 = "Vainilla";
    private String heladoJugador2 = "Vainilla";
    private String modoSeleccionado = "";
    private String perfilMaquina1 = "expert"; // Para PvsM y MvsM
    private String perfilMaquina2 = "expert"; // Para MvsM

    // Botones que referenciamos
    private JButton botonJugar;
    private JButton botonPvsP;
    private JButton botonPvsM;
    private JButton botonMvsM;
    private JButton botonJugador1;
    private JButton botonJugador2;
    private JButton botonUnJugadorVainilla;
    private JButton botonUnJugadorChocolate;
    private JButton botonUnJugadorFresa;
    private JButton botonDosJ1Vainilla;
    private JButton botonDosJ1Chocolate;
    private JButton botonDosJ1Fresa;
    private JButton botonDosJ2Vainilla;
    private JButton botonDosJ2Chocolate;
    private JButton botonDosJ2Fresa;
    
    // Temporizador para el juego
    private Timer gameLoopTimer;
    
    //Imagenes del Juego 
    private Image imgFondoTablero, imgBloqueHielo;
    private Image imgHeladoVainilla, imgHeladoChocolate, imgHeladoFresa;
    private Image imgTroll, imgMaceta, imgNarval, imgCalamarNaranja;
    private Image imgCereza, imgPlatano, imgPina, imgUva, imgCactus;
    private Image imgFogata, imgBaldosaCaliente;

    // Constructor
    public BadDopoCreamGUI() {
        setTitle("Bad Dopo Cream");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 700);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setLayout(null);

        // Inicializamos el modelo y controlador
        juego = new Juego();
        controlador = new Controlador(juego, this);

        // Crear paneles
        crearPanelInicio();
        crearPanelModos();
        crearPanelSeleccionModo();
        crearPanelSeleccionJugadores();          // pantalla 3
        crearPanelSeleccionUnJugadorHelados();   // pantalla 3.1
        crearPanelSelecciondosJugadorHelados();  // pantalla 3.2
        crearPanelSeleccionPerfilesMaquina();    // pantalla 3.3 (para PvsM y MvsM)
        crearPanelSeleccionNiveles();

        // Añadir paneles al content pane
        getContentPane().add(panelInicio);
        getContentPane().add(panelModos);
        getContentPane().add(panelSeleccionModo);
        getContentPane().add(panelSeleccionJugadores);
        getContentPane().add(panelSeleccionUnJugadorHelados);
        getContentPane().add(panelSelecciondosJugadorHelados);
        getContentPane().add(panelSeleccionPerfilesMaquina);
        getContentPane().add(panelSeleccionNiveles);

        // Iniciar visibilidades
        panelInicio.setVisible(true);
        panelModos.setVisible(false);
        panelSeleccionModo.setVisible(false);
        panelSeleccionJugadores.setVisible(false);
        panelSeleccionUnJugadorHelados.setVisible(false);
        panelSelecciondosJugadorHelados.setVisible(false);
        panelSeleccionPerfilesMaquina.setVisible(false);
        panelSeleccionNiveles.setVisible(false);

        // Preparar acciones de cada ventana
        prepareActions();
    }

    // Crear panel de inicio
    private void crearPanelInicio() {
        panelInicio = new JPanel();
        panelInicio.setLayout(null);
        panelInicio.setBounds(0, 0, 900, 700);
        panelInicio.setOpaque(false);

        JLabel titulo = new JLabel("BAD DOPO CREAM");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 40));
        titulo.setForeground(Color.BLACK);
        titulo.setBounds(250, 37, 450, 50);
        panelInicio.add(titulo);

        JButton botonStart = new JButton("Click Para Empezar");
        botonStart.setVerticalAlignment(SwingConstants.BOTTOM);
        botonStart.setFont(new Font("Segoe UI", Font.BOLD, 16));
        botonStart.setBounds(320, 623, 250, 28);
        botonStart.setBackground(Color.LIGHT_GRAY);
        botonStart.setForeground(Color.BLACK);
        botonStart.setFocusPainted(false);
        panelInicio.add(botonStart);

        // Fondo como etiqueta de imagen personalizada(inicio)
        try {
            java.net.URL url = getClass().getResource("/BadDopoCream/presentacion/recursos/BadDopoCream.jpeg");
            if (url != null) {
                ImageIcon imagenOriginal = new ImageIcon(url);
                java.awt.Image imagenEscalada = imagenOriginal.getImage().getScaledInstance(700, 500, java.awt.Image.SCALE_SMOOTH);
                ImageIcon fondo = new ImageIcon(imagenEscalada);
                JLabel fondoLabel = new JLabel(fondo);
                fondoLabel.setBounds(100, 100, 700, 500);
                panelInicio.add(fondoLabel);
            } else {
                System.err.println("Imagen de fondo no encontrada: BadDopoCream.jpeg");
            }
        } catch (Exception ex) {
            System.err.println("Error cargando imagen de inicio: " + ex.getMessage());
        }

        botonStart.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelInicio.setVisible(false);
                panelModos.setVisible(true);
            }
        });
    }


    /* Crea y configura el panel principal donde se muestran los botones
    * "Jugar", "Configuración" y "Salir", junto con el título y el fondo personalizado inicial.
    **/
    private void crearPanelModos() {
        panelModos = new JPanel();
        panelModos.setLayout(null);
        panelModos.setBounds(0, 0, 900, 700);
        panelModos.setOpaque(false);

        JLabel tituloModos = new JLabel("BAD DOPO CREAM");
        tituloModos.setFont(new Font("Segoe UI", Font.BOLD, 40));
        tituloModos.setForeground(Color.BLACK);
        tituloModos.setBounds(250, 37, 450, 50);
        panelModos.add(tituloModos);

        botonJugar = new JButton("Jugar");
        botonJugar.setFont(new Font("Segoe UI", Font.BOLD, 20));
        botonJugar.setBounds(200, 610, 150, 35);
        botonJugar.setBackground(Color.LIGHT_GRAY);
        botonJugar.setForeground(Color.BLACK);
        botonJugar.setFocusPainted(false);
        panelModos.add(botonJugar);

        JButton botonConfig = new JButton("Configuración");
        botonConfig.setFont(new Font("Segoe UI", Font.BOLD, 20));
        botonConfig.setBounds(370, 610, 180, 35);
        botonConfig.setBackground(Color.LIGHT_GRAY);
        botonConfig.setForeground(Color.BLACK);
        botonConfig.setFocusPainted(false);
        panelModos.add(botonConfig);

        JButton botonSalir = new JButton("Salir");
        botonSalir.setFont(new Font("Segoe UI", Font.BOLD, 20));
        botonSalir.setBounds(570, 610, 150, 35);
        botonSalir.setBackground(Color.LIGHT_GRAY);
        botonSalir.setForeground(Color.BLACK);
        botonSalir.setFocusPainted(false);
        panelModos.add(botonSalir);

        // Fondo del panel 
        try {
            java.net.URL url = getClass().getResource("/BadDopoCream/presentacion/recursos/BadDopoCream.jpeg");
            // Si se encuentra la imagen, se escala y se agrega al panel
            if (url != null) {
                ImageIcon imagenOriginal = new ImageIcon(url);
                java.awt.Image imagenEscalada = imagenOriginal.getImage().getScaledInstance(700, 500, java.awt.Image.SCALE_SMOOTH);
                ImageIcon fondo = new ImageIcon(imagenEscalada);
                JLabel fondoModos = new JLabel(fondo);
                fondoModos.setBounds(100, 100, 700, 500);
                panelModos.add(fondoModos);
            }
        } catch (Exception ex) {
            System.err.println("Error cargando fondo de modos: " + ex.getMessage());
        }

        // Listeners de los botones

        /* Al presionar "Jugar" se oculta este panel y se muestra el de selección de modo */
        botonJugar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelModos.setVisible(false);
                panelSeleccionModo.setVisible(true);
            }
        });
        /* Al presionar "Configuración" se muestra un mensaje indicando que está pendiente(Falta Implementacion) */
        botonConfig.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(BadDopoCreamGUI.this, "Configuración (pendiente)");
            }
        });
        
        botonSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int confirmar = JOptionPane.showConfirmDialog(BadDopoCreamGUI.this, "¿Estás seguro que deseas salir del juego?", "Salir del Juego", JOptionPane.YES_NO_OPTION);
                if (confirmar == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });
    }

    /* Crea el panel donde el usuario elige
    * el modo de juego: PvP, PvM o MvM.
    **/ 
    private void crearPanelSeleccionModo() {
        panelSeleccionModo = new JPanel();
        panelSeleccionModo.setLayout(null);
        panelSeleccionModo.setBounds(0, 0, 900, 700);
        panelSeleccionModo.setOpaque(false);

        JLabel tituloSeleccion = new JLabel("Selecciona un modo de juego");
        tituloSeleccion.setFont(new Font("Segoe UI", Font.BOLD, 30));
        tituloSeleccion.setForeground(Color.BLACK);
        tituloSeleccion.setBounds(210, 37, 550, 50);
        panelSeleccionModo.add(tituloSeleccion);

        botonPvsP = new JButton("Jugador vs Jugador");
        botonPvsP.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonPvsP.setBounds(300, 200, 300, 45);
        botonPvsP.setBackground(Color.LIGHT_GRAY);
        botonPvsP.setForeground(Color.BLACK);
        botonPvsP.setFocusPainted(false);
        panelSeleccionModo.add(botonPvsP);

        botonPvsM = new JButton("Jugador vs Maquina");
        botonPvsM.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonPvsM.setBounds(300, 280, 300, 45);
        botonPvsM.setBackground(Color.LIGHT_GRAY);
        botonPvsM.setForeground(Color.BLACK);
        botonPvsM.setFocusPainted(false);
        panelSeleccionModo.add(botonPvsM);

        botonMvsM = new JButton("Maquina vs Maquina");
        botonMvsM.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonMvsM.setBounds(300, 360, 300, 45);
        botonMvsM.setBackground(Color.LIGHT_GRAY);
        botonMvsM.setForeground(Color.BLACK);
        botonMvsM.setFocusPainted(false);
        panelSeleccionModo.add(botonMvsM);

        JButton botonVolver = new JButton("Volver");
        botonVolver.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonVolver.setBounds(300, 440, 300, 45);
        botonVolver.setBackground(Color.LIGHT_GRAY);
        botonVolver.setForeground(Color.BLACK);
        botonVolver.setFocusPainted(false);
        panelSeleccionModo.add(botonVolver);

        // Fondo imagen del panel
        try {
            java.net.URL url = getClass().getResource("/BadDopoCream/presentacion/recursos/BadDopoCream.jpeg");
            /* Si la imagen existe, se escala y se agrega al panel */
            if (url != null) {
                ImageIcon fondoImg = new ImageIcon(url);
                Image imagen = fondoImg.getImage().getScaledInstance(700, 500, java.awt.Image.SCALE_SMOOTH);
                JLabel fondoSeleccion = new JLabel(new ImageIcon(imagen));
                fondoSeleccion.setBounds(100, 100, 700, 500);
                panelSeleccionModo.add(fondoSeleccion);
            }
        } catch (Exception ex) {
            System.err.println("Error cargando fondo de selección de modo: " + ex.getMessage());
        }

        // Listeners
        /* Opción: Jugador vs Jugador*/
        botonPvsP.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                modoJuegoActual = "PvsP";
                panelSeleccionModo.setVisible(false);
                panelSeleccionJugadores.setVisible(true);
            }
        });

        /* Opción: Jugador vs Maquina*/
        botonPvsM.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                modoJuegoActual = "PvsM";
                panelSeleccionModo.setVisible(false);
                // PvsM va directo a panel de dos helados (J1 humano + Máquina)
                panelSelecciondosJugadorHelados.setVisible(true);
            }
        });

        /* Opción: Maquina vs Maquina*/
        botonMvsM.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                modoJuegoActual = "MvsM";
                panelSeleccionModo.setVisible(false);
                // MvsM va directo a perfiles de máquina (sin selección de jugadores ni helados)
                panelSeleccionPerfilesMaquina.setVisible(true);
            }
        });

        botonVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelSeleccionModo.setVisible(false);
                panelModos.setVisible(true);
            }
        });
    }

    // Método: crearPanelSeleccionJugadores (Pantalla 3)  
    private void crearPanelSeleccionJugadores() {
        panelSeleccionJugadores = new JPanel();
        panelSeleccionJugadores.setLayout(null);
        panelSeleccionJugadores.setBounds(0, 0, 900, 700);
        panelSeleccionJugadores.setOpaque(false);

        JLabel seleccionJugadores = new JLabel("");
        seleccionJugadores.setFont(new Font("Segoe UI", Font.BOLD, 30));
        seleccionJugadores.setForeground(Color.BLACK);
        seleccionJugadores.setBounds(170, 40, 700, 50);
        panelSeleccionJugadores.add(seleccionJugadores);

        JButton botonJugador1 = new JButton();
        botonJugador1.setBounds(150, 220, 170, 170);    
        botonJugador1.setFocusPainted(false);
        botonJugador1.setOpaque(false);
        botonJugador1.setContentAreaFilled(false);
        botonJugador1.setBorderPainted(false);
        panelSeleccionJugadores.add(botonJugador1);

        JButton botonJugador2 = new JButton();
        botonJugador2.setBounds(550, 220, 170, 170);
        botonJugador2.setFocusPainted(false);
        botonJugador2.setFocusPainted(false);
        botonJugador2.setOpaque(false);
        botonJugador2.setContentAreaFilled(false);
        botonJugador2.setBorderPainted(false);
        panelSeleccionJugadores.add(botonJugador2);

        JButton botonAtras = new JButton("");
        botonAtras.setBounds(372, 560, 150, 45);
        botonAtras.setFocusPainted(false);
        botonAtras.setFocusPainted(false);
        botonAtras.setOpaque(false);
        botonAtras.setContentAreaFilled(false);
        botonAtras.setBorderPainted(false);
        panelSeleccionJugadores.add(botonAtras);

        //fondo- Se agrega AL FINAL para que quede detrás
        try {
            ImageIcon imagenOriginalJugadores = new ImageIcon(getClass().getResource("/BadDopoCream/presentacion/recursos/Jugadores.jpg"));
            if (imagenOriginalJugadores.getImage() != null) {
                java.awt.Image imagenEscaladaJugadores = imagenOriginalJugadores.getImage().getScaledInstance(900, 700, java.awt.Image.SCALE_SMOOTH);
                ImageIcon fondoJugadores = new ImageIcon(imagenEscaladaJugadores);
                JLabel fondoLabelJugadores = new JLabel(fondoJugadores);
                fondoLabelJugadores.setBounds(0, 0, 900, 700);
                panelSeleccionJugadores.add(fondoLabelJugadores);
            } else {
                // Si no se carga la imagen, usar un fondo de color
                JLabel fondoColor = new JLabel();
                fondoColor.setOpaque(true);
                fondoColor.setBackground(new Color(70, 130, 180));
                fondoColor.setBounds(0, 0, 900, 700);
                panelSeleccionJugadores.add(fondoColor);
            }
        } catch (Exception ex) {
            System.err.println("No se pudo cargar Jugadores.jpg: " + ex.getMessage());
            // Fondo de color alternativo
            JLabel fondoColor = new JLabel();
            fondoColor.setOpaque(true);
            fondoColor.setBackground(new Color(70, 130, 180));
            fondoColor.setBounds(0, 0, 900, 700);
            panelSeleccionJugadores.add(fondoColor);
        }

        // Listeners para abrir pantallas 3.1 y 3.2
        botonJugador1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Un jugador -> ir a selección de helado 1 jugador (Player o PvsM)
                panelSeleccionJugadores.setVisible(false);
                panelSeleccionUnJugadorHelados.setVisible(true);
            }
        });

        botonJugador2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Dos jugadores -> ir a selección de helados para dos jugadores (solo PvsP)
                panelSeleccionJugadores.setVisible(false);
                panelSelecciondosJugadorHelados.setVisible(true);
            }
        });

        botonAtras.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelSeleccionJugadores.setVisible(false);
                panelSeleccionModo.setVisible(true);
            }
        });
    }

    // Método: crearPanelSeleccionUnJugadorHelados (Pantalla 3.1)
    private void crearPanelSeleccionUnJugadorHelados() {
        panelSeleccionUnJugadorHelados = new JPanel();
        panelSeleccionUnJugadorHelados.setLayout(null);
        panelSeleccionUnJugadorHelados.setBounds(0, 0, 900, 700);
        panelSeleccionUnJugadorHelados.setOpaque(false);

        JLabel titulo = new JLabel("");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 36));
        titulo.setForeground(Color.WHITE);
        titulo.setBounds(200, 30, 600, 50);
        panelSeleccionUnJugadorHelados.add(titulo);

        JButton botonVainilla = new JButton("");
        botonVainilla.setBounds(420, 220, 75, 75);
        botonVainilla.setFocusPainted(false);
        botonVainilla.setFocusPainted(false);
        botonVainilla.setOpaque(false);
        botonVainilla.setContentAreaFilled(false);
        botonVainilla.setBorderPainted(false);
        panelSeleccionUnJugadorHelados.add(botonVainilla);

        JButton botonChocolate = new JButton("");
        botonChocolate.setBounds(325, 200, 75, 75);
        botonChocolate.setFocusPainted(false);
        botonChocolate.setFocusPainted(false);
        botonChocolate.setOpaque(false);
        botonChocolate.setContentAreaFilled(false);
        botonChocolate.setBorderPainted(false);
        panelSeleccionUnJugadorHelados.add(botonChocolate);

        JButton botonFresa = new JButton("");
        botonFresa.setBounds(515, 200,75, 75);
        botonFresa.setFocusPainted(false);
        botonFresa.setFocusPainted(false);
        botonFresa.setOpaque(false);
        botonFresa.setContentAreaFilled(false);
        botonFresa.setBorderPainted(false);
        panelSeleccionUnJugadorHelados.add(botonFresa);
        
        JButton botonVolver = new JButton("");
        botonVolver.setBounds(372, 560, 150, 45);
        botonVolver.setFocusPainted (false);
        botonVolver.setFocusPainted(false);
        botonVolver.setOpaque(false);
        botonVolver.setContentAreaFilled(false);
        botonVolver.setBorderPainted(false);
        panelSeleccionUnJugadorHelados.add(botonVolver);

        // Listeners: guardar selección y avanzar según el modo
        botonVainilla.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador1 = "Vainilla";
                panelSeleccionUnJugadorHelados.setVisible(false);
                // Modo Player va directo a niveles
                modoJuegoActual = "Player";
                panelSeleccionNiveles.setVisible(true);
            }
        });

        botonChocolate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador1 = "Chocolate";
                panelSeleccionUnJugadorHelados.setVisible(false);
                // Modo Player va directo a niveles
                modoJuegoActual = "Player";
                panelSeleccionNiveles.setVisible(true);
            }
        });

        botonFresa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador1 = "Fresa";
                panelSeleccionUnJugadorHelados.setVisible(false);
                // Modo Player va directo a niveles
                modoJuegoActual = "Player";
                panelSeleccionNiveles.setVisible(true);
            }
        });

        botonVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelSeleccionUnJugadorHelados.setVisible(false);
                panelSeleccionJugadores.setVisible(true);
            }
        });

        // fondo - Se agrega al final para que quede detrás
        try {
            ImageIcon imagenOriginalPlayer1 = new ImageIcon(getClass().getResource("/BadDopoCream/presentacion/recursos/JugadorUno.jpg"));
            if (imagenOriginalPlayer1.getImage() != null) {
                java.awt.Image imagenEscaladaPlayer1 = imagenOriginalPlayer1.getImage().getScaledInstance(900, 700, java.awt.Image.SCALE_SMOOTH);
                ImageIcon fondoPlayer1 = new ImageIcon(imagenEscaladaPlayer1);
                JLabel fondoLabelPlayer1 = new JLabel(fondoPlayer1);
                fondoLabelPlayer1.setBounds(0, 0, 900, 700);
                panelSeleccionUnJugadorHelados.add(fondoLabelPlayer1);
            } else {
                JLabel fondoColor = new JLabel();
                fondoColor.setOpaque(true);
                fondoColor.setBackground(new Color(100, 180, 100));
                fondoColor.setBounds(0, 0, 900, 700);
                panelSeleccionUnJugadorHelados.add(fondoColor);
            }
        } catch (Exception ex) {
            System.err.println("No se pudo cargar JugadorUno.jpg: " + ex.getMessage());
            JLabel fondoColor = new JLabel();
            fondoColor.setOpaque(true);
            fondoColor.setBackground(new Color(100, 180, 100));
            fondoColor.setBounds(0, 0, 900, 700);
            panelSeleccionUnJugadorHelados.add(fondoColor);
        }
    }

    /**
    * Método: crearPanelSelecciondosJugadorHelados (Pantalla 3.2)
    * Pantalla donde el usuario elige si jugará 1 jugador o 2.
    */
    private void crearPanelSelecciondosJugadorHelados() {
        panelSelecciondosJugadorHelados = new JPanel();
        panelSelecciondosJugadorHelados.setLayout(null);
        panelSelecciondosJugadorHelados.setBounds(0, 0, 900, 700);
        panelSelecciondosJugadorHelados.setOpaque(false);

        // Jugador 1 columna
        JButton j1Vainilla = new JButton("");
        j1Vainilla.setBounds(220, 200, 75, 75);
        j1Vainilla.setFocusPainted(false);
        j1Vainilla.setFocusPainted(false);
        j1Vainilla.setOpaque(false);
        j1Vainilla.setContentAreaFilled(false);
        j1Vainilla.setBorderPainted(false);
        panelSelecciondosJugadorHelados.add(j1Vainilla);

        JButton j1Chocolate = new JButton("");
        j1Chocolate.setBounds(130, 180, 75, 75);
        j1Chocolate.setFocusPainted(false);
        j1Chocolate.setFocusPainted(false);
        j1Chocolate.setOpaque(false);
        j1Chocolate.setContentAreaFilled(false);
        j1Chocolate.setBorderPainted(false);
        panelSelecciondosJugadorHelados.add(j1Chocolate);

        JButton j1Fresa = new JButton("");
        j1Fresa.setBounds(310, 180, 75, 75);
        j1Fresa.setFocusPainted(false);
        j1Fresa.setFocusPainted(false);
        j1Fresa.setOpaque(false);
        j1Fresa.setContentAreaFilled(false);
        j1Fresa.setBorderPainted(false);
        panelSelecciondosJugadorHelados.add(j1Fresa);

        // Jugador 2 columna
     
        JButton j2Vainilla = new JButton("");
        j2Vainilla.setBounds(610, 200, 75, 75);
        j2Vainilla.setFocusPainted(false);
        j2Vainilla.setFocusPainted(false);
        j2Vainilla.setOpaque(false);
        j2Vainilla.setContentAreaFilled(false);
        j2Vainilla.setBorderPainted(false);
        panelSelecciondosJugadorHelados.add(j2Vainilla);

        JButton j2Chocolate = new JButton("");
        j2Chocolate.setBounds(520,180, 75, 75);
        j2Chocolate.setFocusPainted(false);
        j2Chocolate.setFocusPainted(false);
        j2Chocolate.setOpaque(false);
        j2Chocolate.setContentAreaFilled(false);
        j2Chocolate.setBorderPainted(false);
        panelSelecciondosJugadorHelados.add(j2Chocolate);

        JButton j2Fresa = new JButton("");
        j2Fresa.setBounds(700, 180, 75, 75);
        j2Fresa.setFocusPainted(false);
        j2Fresa.setFocusPainted(false);
        j2Fresa.setOpaque(false);
        j2Fresa.setContentAreaFilled(false);
        j2Fresa.setBorderPainted(false);
        panelSelecciondosJugadorHelados.add(j2Fresa);

        // Boton continuar 
        JButton botonContinuar = new JButton("");
        botonContinuar.setBounds(495, 545, 265, 55);
        botonContinuar.setFocusPainted(false);
        botonContinuar.setFocusPainted(false);
        botonContinuar.setOpaque(false);
        botonContinuar.setContentAreaFilled(false);
        botonContinuar.setBorderPainted(false);
        panelSelecciondosJugadorHelados.add(botonContinuar);

        //Boton volver
        JButton botonVolver = new JButton("");
        botonVolver.setBounds(150, 545, 240, 55);
        botonVolver.setFocusPainted(false);
        botonVolver.setFocusPainted(false);
        botonVolver.setOpaque(false);
        botonVolver.setContentAreaFilled(false);
        botonVolver.setBorderPainted(false);
        panelSelecciondosJugadorHelados.add(botonVolver);

        // Listeners helados para J1
        j1Vainilla.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador1 = "Vainilla";
            }
        });
        j1Chocolate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador1 = "Chocolate";
            }
        });
        j1Fresa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador1 = "Fresa";
            }
        });

        // Listeners helados para J2
        j2Vainilla.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador2 = "Vainilla";
            }
        });
        j2Chocolate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador2 = "Chocolate";
            }
        });
        j2Fresa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador2 = "Fresa";
            }
        });

        // Botón continuar para ir a niveles (PvsP) o perfiles (PvsM)
        botonContinuar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // si no se seleccionó alguno, se asume el helado Vainilla por defecto
                if (heladoJugador1 == null || heladoJugador1.isEmpty()) heladoJugador1 = "Vainilla";
                if (heladoJugador2 == null || heladoJugador2.isEmpty()) heladoJugador2 = "Vainilla";

                panelSelecciondosJugadorHelados.setVisible(false);
                
                if ("PvsM".equals(modoJuegoActual)) {
                    // PvsM va a selección de perfiles de máquina
                    panelSeleccionPerfilesMaquina.setVisible(true);
                } else {
                    // PvsP va directo a niveles
                    panelSeleccionNiveles.setVisible(true);
                }
            }
        });

        botonVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelSelecciondosJugadorHelados.setVisible(false);
                // Volver según el modo
                if ("PvsM".equals(modoJuegoActual)) {
                    // PvsM vuelve a selección de modo
                    panelSeleccionModo.setVisible(true);
                } else {
                    // PvsP vuelve a selección de jugadores
                    panelSeleccionJugadores.setVisible(true);
                }
            }
        });

        // Fondo de la pantalla al final
        try {
            ImageIcon imagenOriginalPlayer2 = new ImageIcon(getClass().getResource("/BadDopoCream/presentacion/recursos/JugadoresDos.jpg"));
            if (imagenOriginalPlayer2.getImage() != null) {
                java.awt.Image imagenEscaladaPlayer2 = imagenOriginalPlayer2.getImage().getScaledInstance(900, 700, java.awt.Image.SCALE_SMOOTH);
                ImageIcon fondoPlayer2 = new ImageIcon(imagenEscaladaPlayer2);
                JLabel fondoLabelPlayer2 = new JLabel(fondoPlayer2);
                fondoLabelPlayer2.setBounds(0, 0, 900, 700);
                panelSelecciondosJugadorHelados.add(fondoLabelPlayer2);
            } else {
                JLabel fondoColor = new JLabel();
                fondoColor.setOpaque(true);
                fondoColor.setBackground(new Color(180, 100, 150));
                fondoColor.setBounds(0, 0, 900, 700);
                panelSelecciondosJugadorHelados.add(fondoColor);
            }
        } catch (Exception ex) {
            System.err.println("No se pudo cargar JugadoresDos.jpg: " + ex.getMessage());
            JLabel fondoColor = new JLabel();
            fondoColor.setOpaque(true);
            fondoColor.setBackground(new Color(180, 100, 150));
            fondoColor.setBounds(0, 0, 900, 700);
            panelSelecciondosJugadorHelados.add(fondoColor);
        }
    }

    /**
    * Método: crearPanelSeleccionPerfilesMaquina (Pantalla 3.3)
    * Pantalla donde se selecciona el perfil de la(s) máquina(s): hungry, fearful, expert
    */
    private void crearPanelSeleccionPerfilesMaquina() {
        panelSeleccionPerfilesMaquina = new PanelConFondo("/BadDopoCream/presentacion/recursos/BadDopoCream.jpeg");
        panelSeleccionPerfilesMaquina.setLayout(null);
        panelSeleccionPerfilesMaquina.setBounds(0, 0, 900, 700);

        JLabel titulo = new JLabel("Selecciona el perfil de la máquina");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 32));
        titulo.setForeground(Color.BLACK);
        titulo.setBounds(190, 40, 600, 50);
        panelSeleccionPerfilesMaquina.add(titulo);

        // Botón Hungry
        JButton botonHungry = new JButton("Hungry");
        botonHungry.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonHungry.setBounds(300, 180, 300, 50);
        botonHungry.setBackground(Color.LIGHT_GRAY);
        botonHungry.setForeground(Color.BLACK);
        botonHungry.setFocusPainted(false);
        panelSeleccionPerfilesMaquina.add(botonHungry);

        JLabel labelHungry = new JLabel("Su interés principal es recoger frutas");
        labelHungry.setFont(new Font("Segoe UI", Font.BOLD, 14));
        labelHungry.setBounds(310, 235, 300, 20);
        panelSeleccionPerfilesMaquina.add(labelHungry);

        // Botón Fearful
        JButton botonFearful = new JButton("Fearful");
        botonFearful.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonFearful.setBounds(300, 290, 300, 50);
        botonFearful.setBackground(Color.LIGHT_GRAY);
        botonFearful.setForeground(Color.BLACK);
        botonFearful.setFocusPainted(false);
        panelSeleccionPerfilesMaquina.add(botonFearful);

        JLabel labelFearful = new JLabel("Su interés es protegerse de los enemigos");
        labelFearful.setFont(new Font("Segoe UI", Font.BOLD, 14));
        labelFearful.setBounds(310, 345, 300, 20);
        panelSeleccionPerfilesMaquina.add(labelFearful);

        // Botón Expert
        JButton botonExpert = new JButton("Expert");
        botonExpert.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonExpert.setBounds(300, 400, 300, 50);
        botonExpert.setBackground(Color.LIGHT_GRAY);
        botonExpert.setForeground(Color.BLACK);
        botonExpert.setFocusPainted(false);
        panelSeleccionPerfilesMaquina.add(botonExpert);

        JLabel labelExpert = new JLabel("Realiza los mejores movimientos (experto)");
        labelExpert.setFont(new Font("Segoe UI", Font.BOLD, 14));
        labelExpert.setBounds(310, 455, 300, 20);
        panelSeleccionPerfilesMaquina.add(labelExpert);

        // Botón Volver
        JButton botonVolver = new JButton("Volver");
        botonVolver.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonVolver.setBounds(300, 520, 300, 45);
        botonVolver.setBackground(Color.LIGHT_GRAY);
        botonVolver.setForeground(Color.BLACK);
        botonVolver.setFocusPainted(false);
        panelSeleccionPerfilesMaquina.add(botonVolver);

        // Ya no se necesita agregar fondo manualmente, PanelConFondo lo maneja

        // Listeners
        botonHungry.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                perfilMaquina1 = "hungry";
                panelSeleccionPerfilesMaquina.setVisible(false);
                
                if ("MvsM".equals(modoJuegoActual)) {
                    // MvsM: Asignar helados aleatorios y ir a selección de niveles
                    heladoJugador1 = "Chocolate";
                    heladoJugador2 = "Vainilla";
                    perfilMaquina2 = perfilMaquina1; // Ambas máquinas con el mismo perfil
                    panelSeleccionNiveles.setVisible(true);
                } else {
                    // PvsM va a selección de niveles
                    panelSeleccionNiveles.setVisible(true);
                }
            }
        });

        botonFearful.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                perfilMaquina1 = "fearful";
                panelSeleccionPerfilesMaquina.setVisible(false);
                
                if ("MvsM".equals(modoJuegoActual)) {
                    // MvsM: Asignar helados aleatorios y ir a selección de niveles
                    heladoJugador1 = "Fresa";
                    heladoJugador2 = "Chocolate";
                    perfilMaquina2 = perfilMaquina1; // Ambas máquinas con el mismo perfil
                    panelSeleccionNiveles.setVisible(true);
                } else {
                    // PvsM va a selección de niveles
                    panelSeleccionNiveles.setVisible(true);
                }
            }
        });

        botonExpert.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                perfilMaquina1 = "expert";
                panelSeleccionPerfilesMaquina.setVisible(false);
                
                if ("MvsM".equals(modoJuegoActual)) {
                    // MvsM: Asignar helados aleatorios y ir a selección de niveles
                    heladoJugador1 = "Vainilla";
                    heladoJugador2 = "Fresa";
                    perfilMaquina2 = perfilMaquina1; // Ambas máquinas con el mismo perfil
                    panelSeleccionNiveles.setVisible(true);
                } else {
                    // PvsM va a selección de niveles
                    panelSeleccionNiveles.setVisible(true);
                }
            }
        });

        botonVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelSeleccionPerfilesMaquina.setVisible(false);
                // Volver según el modo
                if ("MvsM".equals(modoJuegoActual)) {
                    // MvsM vuelve a selección de modo
                    panelSeleccionModo.setVisible(true);
                } else if ("PvsM".equals(modoJuegoActual)) {
                    // PvsM vuelve a selección de dos helados
                    panelSelecciondosJugadorHelados.setVisible(true);
                }
            }
        });
    }

    /**
    * Método: crearPanelSeleccionNiveles
    * Pantalla donde se elige el nivel antes de iniciar el juego.
    */
    private void crearPanelSeleccionNiveles() {
        // Panel con fondo personalizado (clase PanelConFondo)
        panelSeleccionNiveles = new PanelConFondo("/BadDopoCream/presentacion/recursos/BadDopoCream.jpeg");
        panelSeleccionNiveles.setLayout(null);
        panelSeleccionNiveles.setBounds(0, 0, 900, 700);

        JLabel tituloNiveles = new JLabel("Selecciona un nivel");
        tituloNiveles.setFont(new Font("Segoe UI", Font.BOLD, 40));
        tituloNiveles.setForeground(Color.BLACK);
        tituloNiveles.setBounds(270, 37, 450, 50);
        panelSeleccionNiveles.add(tituloNiveles);

        //Boton del nivel uno
        JButton botonNivelUno = new JButton("Nivel 1");
        botonNivelUno.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonNivelUno.setBounds(300, 250, 300, 45);
        panelSeleccionNiveles.add(botonNivelUno);

        //Boton del nivel dos
        JButton botonNivelDos = new JButton("Nivel 2");
        botonNivelDos.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonNivelDos.setBounds(300, 320, 300, 45);
        panelSeleccionNiveles.add(botonNivelDos);


        //Boton del nivel tres  
        JButton botonNivelTres = new JButton("Nivel 3");
        botonNivelTres.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonNivelTres.setBounds(300, 390, 300, 45);
        panelSeleccionNiveles.add(botonNivelTres);

        //Boton volver
        JButton botonVolver = new JButton("Volver");
        botonVolver.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonVolver.setBounds(300, 460, 300, 45);
        panelSeleccionNiveles.add(botonVolver);

        // Listeners de los botones de nivel
        botonNivelUno.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                nivelSeleccionado = 1;
                iniciarJuegoDesdeSeleccion();  // Método que inicia el juego según el nivel elegido
            }
        });
    
        botonNivelDos.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                nivelSeleccionado = 2;
                iniciarJuegoDesdeSeleccion();
            }
        });

        botonNivelTres.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                nivelSeleccionado = 3;
                iniciarJuegoDesdeSeleccion();
            }
        });

        botonVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelSeleccionNiveles.setVisible(false);
                // Volver a la pantalla según modo
                if ("PvsP".equals(modoJuegoActual) || "PvsM".equals(modoJuegoActual) || "MvsM".equals(modoJuegoActual)) {
                    // si venimos de selección de jugadores, regresar a ella
                    panelSeleccionJugadores.setVisible(true);
                } else {
                    panelSeleccionModo.setVisible(true);
                }
            }
        });
    }

    /**
    * Método: iniciarJuegoDesdeSeleccion
    * Se ejecuta después de elegir nivel y helado(s).
    * Prepara el juego, crea el panel del tablero y arranca el game loop.
    **/ 
    private void iniciarJuegoDesdeSeleccion() {
        // configurar modo y tipo de helado(s) en el juego
        try {
            // Detener game loop anterior si existe
            detenerGameLoop();
            
            // Se define el modo de juego
            String modo = modoJuegoActual;
            if (modo == null || modo.isEmpty()){
             modo = "Player"; // por defecto
            }
            // Elegimos helado 1 (en modo 1 jugador usamos heladoJugador1, en 2 jugadores ambos)
            String tipoHelado1 = heladoJugador1 != null ? heladoJugador1 : "Vainilla";
            String tipoHelado2 = heladoJugador2 != null ? heladoJugador2 : "Vainilla";

            // Iniciamos el juego primero con la logica, pasando los perfiles de máquina
            juego.iniciarJuego(nivelSeleccionado, tipoHelado1, tipoHelado2, modo, perfilMaquina1, perfilMaquina2);

            // Si se tenia un panelJuego anterior, quitarlo
            if (panelJuego != null) {
                getContentPane().remove(panelJuego);
                panelJuego = null;
            }

            // Crear nuevo TableroPanel 
            panelJuego = new TableroPanel(juego, modo, controlador, this);
            panelJuego.setBounds(0, 0, 900, 700);
            getContentPane().add(panelJuego);

            // Se ocultan todos los paneles de menú
            panelInicio.setVisible(false);
            panelModos.setVisible(false);
            panelSeleccionModo.setVisible(false);
            panelSeleccionJugadores.setVisible(false);
            panelSeleccionUnJugadorHelados.setVisible(false);
            panelSelecciondosJugadorHelados.setVisible(false);
            panelSeleccionPerfilesMaquina.setVisible(false);
            panelSeleccionNiveles.setVisible(false);

            panelJuego.setVisible(true);
            
            // Traer el panel de juego al frente
            getContentPane().setComponentZOrder(panelJuego, 0);

            // Actualizamos componentes 
            getContentPane().revalidate();
            getContentPane().repaint();

            // Configurar controles de teclado
            configurarControles();
            
            // Iniciar game loop despues de configurar todo
            iniciarGameLoop();
            
            // Asegurar foco despues de iniciar el game loop
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    requestFocusInWindow();
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al iniciar el juego: " + e.getMessage());
        }
    }

    /**
    * Método: prepareActions (cerrar ventana)
    * Configura la acción al intentar cerrar la ventana del juego.
    **/
    private void prepareActions() {
        // Evita que la ventana se cierre automáticamente al pulsar la X.
        // Deja el control del cierre en manos del WindowListener.
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        // Añade un listener para detectar cuando el usuario intenta cerrar la ventana
        addWindowListener(new java.awt.event.WindowAdapter() {
            // Este método se ejecuta cuando se intenta cerrar la ventana.
            public void windowClosing(java.awt.event.WindowEvent e) {
                int confirmar = JOptionPane.showConfirmDialog(
                        null,
                        "¿Estás seguro que deseas salir del juego?",
                        "Salir del Juego",
                        JOptionPane.YES_NO_OPTION
                    );
                    if (confirmar == JOptionPane.YES_OPTION) {
                        System.exit(0); // termina toda la aplicación
                    }
            }   
        });
    }
   
    /** 
    * Permite crear un JPanel con una imagen de fondo.
    **/
    private static class PanelConFondo extends JPanel {
        private Image imagen; //Imagen de fondo
        //Constructor que recibe la ruta de la imagen
        public PanelConFondo(String ruta) {
            // Cargar la imagen desde los recursos de la clase
            try {
                ImageIcon icon = new ImageIcon(PanelConFondo.class.getResource(ruta));
                imagen = icon.getImage();
                // Comprobar si la imagen se cargó correctamente
                if (imagen == null) {
                    System.err.println("No se pudo cargar la imagen: " + ruta);
                }
            } catch (Exception e) {
                // Captura cualquier error al cargar la imagen
                System.err.println("Error al cargar imagen: " + ruta);
                e.printStackTrace();
                imagen = null; // En caso de error, la imagen queda como null
            } 
            // Configuraciones del panel
            setLayout(null); //Layout nulo, para posicionar componentes manualmente
            setOpaque(true); //Debe ser opaco para que se pinte el fondo
        }

        
        /* Método que dibuja el panel con su imagen de fondo */
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g); // Llama al método padre para mantener el pintado normal
            if (imagen != null) {
                g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this); //Dibuja la imagen escalada al tamaño del panel
            } else {
                // Si no hay imagen, pintar un color de fondo para debug
                g.setColor(new Color(240, 240, 240));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        }
    }

    /*Metodos para el controlador */
    
    /**
     * Configura los controles del teclado para el juego
     */
    private void configurarControles() {
        // Remover listeners previos del frame
        for (KeyListener kl : getKeyListeners()) {
            removeKeyListener(kl);
        }
        
        // Remover listeners previos del panel si existe
        if (panelJuego != null) {
            for (KeyListener kl : panelJuego.getKeyListeners()) {
                panelJuego.removeKeyListener(kl);
            }
        }
        
        // Crear el KeyListener
        KeyAdapter keyAdapter = new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                
                // Controles Jugador 1 (flechas + espacio)
                if (key == KeyEvent.VK_UP) {
                    controlador.manejarEvento("MOVER_ARRIBA");
                } else if (key == KeyEvent.VK_DOWN) {
                    controlador.manejarEvento("MOVER_ABAJO");
                } else if (key == KeyEvent.VK_LEFT) {
                    controlador.manejarEvento("MOVER_IZQUIERDA");
                } else if (key == KeyEvent.VK_RIGHT) {
                    controlador.manejarEvento("MOVER_DERECHA");
                } else if (key == KeyEvent.VK_SPACE) {
                    controlador.manejarEvento("ACCION_BLOQUE");
                }
                
                // Controles Jugador 2 (WASD + C)
                else if (key == KeyEvent.VK_W) {
                    controlador.manejarEvento("MOVER_ARRIBA_J2");
                } else if (key == KeyEvent.VK_S) {
                    controlador.manejarEvento("MOVER_ABAJO_J2");
                } else if (key == KeyEvent.VK_A) {
                    controlador.manejarEvento("MOVER_IZQUIERDA_J2");
                } else if (key == KeyEvent.VK_D) {
                    controlador.manejarEvento("MOVER_DERECHA_J2");
                } else if (key == KeyEvent.VK_C) {
                    controlador.manejarEvento("ACCION_BLOQUE_J2");
                }
                
                // Pausa (P o ESC)
                else if (key == KeyEvent.VK_P || key == KeyEvent.VK_ESCAPE) {
                    controlador.manejarEvento("PAUSAR_JUEGO");
                }
            }
        };
        
        // Añadir el listener tanto al frame como al panel de juego
        addKeyListener(keyAdapter);
        if (panelJuego != null) {
            panelJuego.addKeyListener(keyAdapter);
            panelJuego.setFocusable(true);
        }
        
        setFocusable(true);
        requestFocusInWindow();
    }
    
    /**
     * Inicia el game loop que actualiza el juego constantemente
     */
    private void iniciarGameLoop() {
        // Detener timer anterior si existe
        if (gameLoopTimer != null && gameLoopTimer.isRunning()) {
            gameLoopTimer.stop();
        }
        
        System.out.println("Iniciando game loop...");
        
        // Crear nuevo timer: 60 FPS (16ms por frame)
        gameLoopTimer = new Timer(16, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controlador.manejarEvento("ACTUALIZAR");
            }
        });
        gameLoopTimer.start();
        
        System.out.println("Game loop iniciado. Timer activo: " + gameLoopTimer.isRunning());
    }
    
    /**
     * Detiene el game loop
     */
    private void detenerGameLoop() {
        if (gameLoopTimer != null && gameLoopTimer.isRunning()) {
            gameLoopTimer.stop();
        }
    }
    
    /**
     * Actualiza la vista (llamado por el controlador)
     */
    public void actualizarVista() {
        if (panelJuego != null && panelJuego.isVisible()) {
            panelJuego.repaint();
        }
    }
    
    /**
     * Reinicia el juego con el modo actual
     */
    public void reiniciarJuego(String modoJuego) {
        this.modoJuegoActual = modoJuego;
        iniciarJuegoDesdeSeleccion();
        // Restaurar el foco después de reiniciar
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                requestFocusInWindow();
            }
        });
    }
    
    /**
     * Vuelve al menú principal
     */
    public void volverAlInicio() {
        detenerGameLoop();
        
        // Ocultar panel de juego
        if (panelJuego != null) {
            panelJuego.setVisible(false);
            getContentPane().remove(panelJuego);
            panelJuego = null;
        }
        
        // Mostrar panel de selección de niveles
        panelSeleccionNiveles.setVisible(true);
        
        getContentPane().revalidate();
        getContentPane().repaint();
    }
    
    /**
     * Restaura el foco a la ventana principal
     */
    public void restaurarFoco() {
        requestFocusInWindow();
    }
    
    /**
     * Muestra mensaje de victoria
     */
    public void mostrarVictoria() {
        detenerGameLoop();
        
        // Determinar si hay dos jugadores
        boolean dosJugadores = juego.getTablero().getHelado2() != null;
        String mensaje = "";
        String titulo = "¡Victoria!";
        
        if (dosJugadores) {
            // Mostrar información del ganador
            int ganador = juego.getJugadorGanador();
            int puntaje1 = juego.getPuntaje();
            int puntaje2 = juego.getPuntaje2();
            
            if (ganador == 1) {
                mensaje = "¡GANA JUGADOR 1!\n\n" +
                         "Puntos Jugador 1: " + puntaje1 + "\n" +
                         "Puntos Jugador 2: " + puntaje2 + "\n\n" +
                         "¡Nivel " + nivelSeleccionado + " completado!";
                titulo = "¡Ganador: Jugador 1!";
            } else if (ganador == 2) {
                mensaje = "¡GANA JUGADOR 2!\n\n" +
                         "Puntos Jugador 1: " + puntaje1 + "\n" +
                         "Puntos Jugador 2: " + puntaje2 + "\n\n" +
                         "¡Nivel " + nivelSeleccionado + " completado!";
                titulo = "¡Ganador: Jugador 2!";
            } else {
                mensaje = "¡EMPATE!\n\n" +
                         "Puntos Jugador 1: " + puntaje1 + "\n" +
                         "Puntos Jugador 2: " + puntaje2 + "\n\n" +
                         "¡Nivel " + nivelSeleccionado + " completado!";
                titulo = "¡Empate!";
            }
        } else {
            mensaje = "¡Felicidades! Has completado el nivel " + nivelSeleccionado + "\n\n" +
                     "Puntos obtenidos: " + juego.getPuntaje();
        }
        
        int opcion = JOptionPane.showOptionDialog(
            this,
            mensaje,
            titulo,
            JOptionPane.YES_NO_OPTION,
            JOptionPane.INFORMATION_MESSAGE,
            null,
            new Object[]{"Siguiente Nivel", "Menú Principal"},
            "Siguiente Nivel"
        );
        
        if (opcion == 0) {
            // Siguiente nivel
            if (nivelSeleccionado < 3) {
                nivelSeleccionado++;
                iniciarJuegoDesdeSeleccion();
            } else {
                mostrarGameOver();
            }
        } else {
            // Volver al menú
            volverAlInicio();
        }
    }
    
    /**
     * Muestra mensaje de derrota
     */
    public void mostrarDerrota() {
        detenerGameLoop();
        
        // Determinar si hay dos jugadores
        boolean dosJugadores = juego.getTablero().getHelado2() != null;
        String mensaje = "";
        String titulo = "Game Over";
        
        if (dosJugadores) {
            // Mostrar ganador por puntos incluso en derrota
            int ganador = juego.getJugadorGanador();
            int puntaje1 = juego.getPuntaje();
            int puntaje2 = juego.getPuntaje2();
            
            if (ganador == 1) {
                mensaje = "Ambos jugadores han sido eliminados.\n\n" +
                         "GANADOR POR PUNTOS: JUGADOR 1\n\n" +
                         "Puntos Jugador 1: " + puntaje1 + "\n" +
                         "Puntos Jugador 2: " + puntaje2;
                titulo = "Game Over - Gana J1";
            } else if (ganador == 2) {
                mensaje = "Ambos jugadores han sido eliminados.\n\n" +
                         "GANADOR POR PUNTOS: JUGADOR 2\n\n" +
                         "Puntos Jugador 1: " + puntaje1 + "\n" +
                         "Puntos Jugador 2: " + puntaje2;
                titulo = "Game Over - Gana J2";
            } else {
                mensaje = "Ambos jugadores han sido eliminados.\n\n" +
                         "EMPATE\n\n" +
                         "Puntos: " + puntaje1 + " cada uno";
                titulo = "Game Over - Empate";
            }
        } else {
            mensaje = "Has perdido.\n\nPuntos obtenidos: " + juego.getPuntaje();
        }
        
        int opcion = JOptionPane.showOptionDialog(
            this,
            mensaje,
            titulo,
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE,
            null,
            new Object[]{"Reintentar", "Menú Principal"},
            "Reintentar"
        );
        
        if (opcion == 0) {
            // Reintentar
            iniciarJuegoDesdeSeleccion();
        } else {
            // Volver al menú
            volverAlInicio();
        }
    }
    
    /**
     * Muestra mensaje de juego completado
     */
    public void mostrarGameOver() {
        detenerGameLoop();
        JOptionPane.showMessageDialog(
            this,
            "¡Felicidades! Has completado todos los niveles\nPuntaje final: " + juego.getPuntaje(),
            "¡Juego Completado!",
            JOptionPane.INFORMATION_MESSAGE
        );
        volverAlInicio();
    }
    
    
    /**
     * Carga una imagen bajo demanda desde los recursos del proyecto.
     */
    private Image cargarImagen(String ruta) {
    	try {
    		URL url = getClass().getResource(ruta);
    		if (url != null) {
    			return new ImageIcon(url).getImage();
    		} else {
    		    System.err.println("No se encontró la imagen: " + ruta);
    		}
    	} catch (Exception e) {
    		System.err.println("Error cargando Imagen: " + ruta + " - " + e.getMessage());
    	}
    	return null;
    }
    
    /**
     * Obtiene una imagen según su nombre (carga bajo demanda con caché).
     */
    public Image getImagen(String nombre) {
        switch (nombre) {
            case "HeladoVainilla":
                if (imgHeladoVainilla == null) imgHeladoVainilla = cargarImagen("/BadDopoCream/presentacion/recursos/helado-Vainillaa.jpg");
                return imgHeladoVainilla;
            case "HeladoChocolate":
                if (imgHeladoChocolate == null) imgHeladoChocolate = cargarImagen("/BadDopoCream/presentacion/recursos/helado-Chocolate.jpg");
                return imgHeladoChocolate;
            case "HeladoFresa":
                if (imgHeladoFresa == null) imgHeladoFresa = cargarImagen("/BadDopoCream/presentacion/recursos/helado-Fresa.jpg");
                return imgHeladoFresa;
            case "Troll":
                if (imgTroll == null) imgTroll = cargarImagen("/BadDopoCream/presentacion/recursos/Troll.png");
                return imgTroll;
            case "Maceta":
                if (imgMaceta == null) imgMaceta = cargarImagen("/BadDopoCream/presentacion/recursos/Maceta.png");
                return imgMaceta;
            case "Narval":
                if (imgNarval == null) imgNarval = cargarImagen("/BadDopoCream/presentacion/recursos/Narval.png");
                return imgNarval;
            case "CalamarNaranja":
                if (imgCalamarNaranja == null) imgCalamarNaranja = cargarImagen("/BadDopoCream/presentacion/recursos/Calamar.jpg");
                return imgCalamarNaranja;
            case "Cereza":
                if (imgCereza == null) imgCereza = cargarImagen("/BadDopoCream/presentacion/recursos/Fruta-cereza.jpg");
                return imgCereza;
            case "Platano":
                if (imgPlatano == null) imgPlatano = cargarImagen("/BadDopoCream/presentacion/recursos/Fruta-Banano.jpg");
                return imgPlatano;
            case "Pina":
                if (imgPina == null) imgPina = cargarImagen("/BadDopoCream/presentacion/recursos/Fruta-Piña.jpg");
                return imgPina;
            case "Uva":
                if (imgUva == null) imgUva = cargarImagen("/BadDopoCream/presentacion/recursos/Fruta-Uva.jpg");
                return imgUva;
            case "Cactus":
                if (imgCactus == null) imgCactus = cargarImagen("/BadDopoCream/presentacion/recursos/Fruta-Cactus.jpg");
                return imgCactus;
            case "Fogata":
                if (imgFogata == null) imgFogata = cargarImagen("/BadDopoCream/presentacion/recursos/Fogata.png");
                return imgFogata;
            case "BaldosaCaliente":
                if (imgBaldosaCaliente == null) imgBaldosaCaliente = cargarImagen("/BadDopoCream/presentacion/recursos/BaldosaCaliente.png");
                return imgBaldosaCaliente;
            case "FondoTablero":
                if (imgFondoTablero == null) imgFondoTablero = cargarImagen("/BadDopoCream/presentacion/recursos/Tablerooo.jpeg");
                return imgFondoTablero;
            case "BloqueHielo":
                if (imgBloqueHielo == null) imgBloqueHielo = cargarImagen("/BadDopoCream/presentacion/recursos/bloqueHielo.jpeg");
                return imgBloqueHielo;
            default:
                return null;
        }
    }
    
    
    public static void main(String[] args) {
        try {
            BadDopoCreamGUI frame = new BadDopoCreamGUI();
            frame.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}