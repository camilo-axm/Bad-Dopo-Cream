package BadDopoCream.controladores;

import BadDopoCream.dominio.Juego;
import BadDopoCream.dominio.utilidades.Direccion;
import BadDopoCream.dominio.utilidades.EstadoJuego;
import BadDopoCream.presentacion.BadDopoCreamGUI;

/**
 * Controlador principal del patrón MVC para Bad Dopo Cream.
 * Gestiona la comunicación entre el Modelo (Juego) y la Vista (BadDopoCreamGUI).
 * 
 * Responsabilidades:
 * - Recibir eventos de la interfaz (clicks, teclas, botones)
 * - Invocar métodos del modelo según el evento
 * - Solicitar actualización de la vista
 * - Coordinar el flujo del juego
 * 
 * @author Camilo Aguirre
 * @version 2025/12/02
 */
public class Controlador {
    private Juego juego;
    private BadDopoCreamGUI vista;
    
    /**
     * Constructor del controlador.
     * @param juego modelo (lógica del juego)
     * @param vista vista (interfaz gráfica)
     */
    public Controlador(Juego juego, BadDopoCreamGUI vista) {
        this.juego = juego;
        this.vista = vista;
    }

    /**
     * Método central para manejar todos los eventos del juego.
     * @param evento cadena que identifica el evento y sus parámetros
     */
    public void manejarEvento(String evento) {
        if (evento == null || evento.isEmpty()) {
            System.err.println("Controlador: Evento nulo o vacío");
            return;
        }
        // Separar el evento de sus parámetros
        String[] partes = evento.split(":");
        String tipoEvento = partes[0];
        
        try {
            switch (tipoEvento) {
                // Eventos de navegacion 
                case "INICIAR_JUEGO":
                    manejarInicioJuego(partes);
                    break;
                    
                case "VOLVER_AL_INICIO":
                    manejarVolverAlInicio();
                    break;
                    
                // Eventos del contrl de juego (pausa, reinicio, siguiente nivel)
                case "PAUSAR_JUEGO":
                    manejarPausaJuego();
                    break;
                    
                case "REINICIAR_JUEGO":
                    manejarReinicioJuego(partes);
                    break;
                    
                case "SIGUIENTE_NIVEL":
                    manejarSiguienteNivel();
                    break;
                    
                // Eventos del movimiento del helado
                case "MOVER_ARRIBA":
                    manejarMovimiento(Direccion.ARRIBA);
                    break;
                    
                case "MOVER_ABAJO":
                    manejarMovimiento(Direccion.ABAJO);
                    break;
                    
                case "MOVER_IZQUIERDA":
                    manejarMovimiento(Direccion.IZQUIERDA);
                    break;
                    
                case "MOVER_DERECHA":
                    manejarMovimiento(Direccion.DERECHA);
                    break;
                    
                // Eventos de accion del helado 
                case "ACCION_BLOQUE":
                    manejarAccionBloque();
                    break;
                    
                // Eventos del movimiento del helado 2 (Jugador 2)
                case "MOVER_ARRIBA_J2":
                    manejarMovimiento2(Direccion.ARRIBA);
                    break;
                    
                case "MOVER_ABAJO_J2":
                    manejarMovimiento2(Direccion.ABAJO);
                    break;
                    
                case "MOVER_IZQUIERDA_J2":
                    manejarMovimiento2(Direccion.IZQUIERDA);
                    break;
                    
                case "MOVER_DERECHA_J2":
                    manejarMovimiento2(Direccion.DERECHA);
                    break;
                    
                // Eventos de accion del helado 2
                case "ACCION_BLOQUE_J2":
                    manejarAccionBloque2();
                    break;
            
                // Eventos de actualización del juego
                case "ACTUALIZAR":
                    manejarActualizacion();
                    break;
                
                // Evento de volver al inicio desde el tablero
                case "VOLVER_INICIO":
                    manejarVolverAlInicio();
                    break;
                    
                default:
                    System.out.println("Evento no reconocido: " + evento);
            }
        } catch (Exception e) {
            System.out.println("Error al manejar evento '" + evento + "': " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // Métodos privados para cada evento
    
    /**
     * Maneja el inicio del juego.
     * Nota: El inicio real se hace en BadDopoCreamGUI.iniciarJuego()
     */
    private void manejarInicioJuego(String[] partes) {
        System.out.println("Juego iniciado");
        vista.actualizarVista();
    }
    
    /**
     * Maneja la pausa/reanudación del juego.
     */
    private void manejarPausaJuego() {
        if (juego != null) {
            juego.pausa();
            
            int estadoActual = juego.getEstado().getEstado();
            if (estadoActual == EstadoJuego.PAUSADO) {
                vista.restaurarFoco();
            }
            vista.restaurarFoco();            
        }
    }

    
    /**
     * Maneja el reinicio del juego.
     */
    private void manejarReinicioJuego(String[] partes) {
        if (partes.length > 1) {
            String modoJuego = partes[1];
            System.out.println("Reiniciando juego en modo " + modoJuego);
            vista.reiniciarJuego(modoJuego);
        } else {
            // Reiniciar con el modo actual
            if (juego != null) {
                System.out.println("Reiniciando nivel actual");
                juego.reiniciarNivel();
                vista.actualizarVista();
            }
        }
    }
    
    /**
     * Maneja el avance al siguiente nivel.
     */
    private void manejarSiguienteNivel() {
        if (juego != null) {
            System.out.println("Avanzando al siguiente nivel");
            juego.siguienteNivel();
            vista.actualizarVista();
        }
    }
    
    /**
     * Maneja el retorno al menú principal.
     */
    private void manejarVolverAlInicio() {
        System.out.println("Volviendo al menú principal");
        if (juego != null) {
            juego.volverAlMenu();
        }
        vista.volverAlInicio();
    }
    
    /**
     * Maneja el movimiento del helado.
     * @param direccion dirección del movimiento
     */
    private void manejarMovimiento(int direccion) {
        if (juego != null && juego.getEstado().getEstado() == EstadoJuego.JUGANDO) {
            Direccion dir = new Direccion(direccion);
            juego.moverHelado(dir);
        }
    }
    
    /**
     * Maneja la acción de crear/romper bloques (tecla ESPACIO).
     */
    private void manejarAccionBloque() {
        if (juego != null && juego.getEstado().getEstado() == EstadoJuego.JUGANDO) {
            juego.accionBloque();
            System.out.println("Acción de bloque ejecutada");
               
        }
    }
    
    /**
     * Maneja el movimiento del jugador 2 (teclas WASD).
     * @param direccion dirección del movimiento
     */
    private void manejarMovimiento2(int direccion) {
        if (juego != null && juego.getEstado().getEstado() == EstadoJuego.JUGANDO) {
            Direccion dir = new Direccion(direccion);
            juego.moverHelado2(dir);
        }
    }
    
    /**
     * Maneja la acción de crear/romper bloques del jugador 2 (tecla C).
     */
    private void manejarAccionBloque2() {
        if (juego != null && juego.getEstado().getEstado() == EstadoJuego.JUGANDO) {
            juego.accionBloque2();
            System.out.println("Acción de bloque J2 ejecutada");
        }
    }
    
    /**
     * Actualiza el estado del juego (llamado por el game loop).
     * Este es el corazón del juego que se ejecuta en cada frame.
     */
    private void manejarActualizacion() {
        if (juego != null) {
            // Actualizar la lógica del juego
            juego.actualizar();
            
            // Verificar cambios de estado (victoria/derrota)
            int estadoActual = juego.getEstado().getEstado();
            
            if (estadoActual == EstadoJuego.VICTORIA) {
                System.out.println("Nivel completado");
                vista.mostrarVictoria();
            } else if (estadoActual == EstadoJuego.DERROTA) {
                System.out.println("Nivel perdido");
                vista.mostrarDerrota();
            } else if (estadoActual == EstadoJuego.GAME_OVER) {
                System.out.println("Juego completado");
                vista.mostrarGameOver();
            }
            
            // Actualizar la vista con el nuevo estado
            vista.actualizarVista();
        }
    }
}