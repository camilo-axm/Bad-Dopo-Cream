package BadDopoCream.dominio.componentes.obstaculos;

import BadDopoCream.dominio.utilidades.Posicion;
import java.awt.*;
import javax.swing.*;

/**
 * Clase Fogata - Obstáculo peligroso para los helados.
 *
 * Las fogatas eliminan a los helados inmediatamente si entran en contacto.
 * Los enemigos son inmunes al fuego.
 *
 * @author Camilo Aguirre
 * @version 2025/12/06
 */
public class Fogata {
    private Posicion posicion;
    
    private boolean encendida;

    private int contadorReencendido;
    
    /** Tiempo para reencender (5 segundos = 300 frames a 60 FPS) */
    private static final int TIEMPO_REENCENDIDO = 300;
    
    
    /**
     * Constructor de Fogata.
     *
     * @param posicion posición de la fogata en el tablero
     */
    public Fogata(Posicion posicion) {
        this.posicion = posicion;
        encendida = true; // Inicia encendida
        contadorReencendido = 0;
    }
    
    /**
     * Actualiza el estado de la fogata.
     * Si está apagada, cuenta el tiempo para reencenderse.
     */
    public void actualizar() {
        if (!encendida) {
            contadorReencendido++;
            
            // Reencender después de 5 segundos
            if (contadorReencendido >= TIEMPO_REENCENDIDO) {
                encendida = true;
                contadorReencendido = 0;
            }
        }
    }
    
    /**
     * Apaga la fogata temporalmente.
     * Esto ocurre cuando se crea y rompe un bloque de hielo sobre ella.
     */
    public void apagar() {
        encendida = false;
        contadorReencendido = 0;
    }
    
    /**
     * Verifica si la fogata está encendida.
     *
     * @return true si está encendida
     */
    public boolean estaEncendida() {
        return encendida;
    }
    
    /**
     * Obtiene la posición de la fogata.
     *
     * @return posición
     */
    public Posicion getPosicion() {
        return posicion;
    }
}
