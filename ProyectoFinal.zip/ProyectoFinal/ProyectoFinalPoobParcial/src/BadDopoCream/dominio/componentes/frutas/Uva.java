package BadDopoCream.dominio.componentes.frutas;

import BadDopoCream.dominio.utilidades.Posicion;
import javax.swing.ImageIcon;

/**
 * Fruta Uva.
 *
 * Es una fruta estática del nivel 1.
 * No se mueve durante el juego, permanece en su posición inicial.
 * Otorga 50 puntos al ser recolectada.
 * @author Camilo Aguirre
 * @version 2025/06/12
 */
public class Uva extends Fruta {
    
    /**
     * Constructor de la Uva.
     *
     * @param posicion posición inicial de la uva en el tablero
     */
    public Uva(Posicion posicion) {
        super(posicion, 50);
    }
    
    /**
     * Actualiza el estado de la uva.
     * Las uvas no tienen comportamiento dinámico (no se mueven).
     */
    @Override
    public void actualizar() {
        // Las uvas no se mueven
    }
    
    /**
     * Retorna el tipo de fruta.
     *
     * @return "Uva"
     */
    @Override
    public String getTipo() {
        return "Uva";
    }
}


