package BadDopoCream.dominio.componentes.frutas;

import BadDopoCream.dominio.utilidades.Posicion;
import javax.swing.ImageIcon;

/**
 * Fruta Cactus.
 *
 * Es una fruta peligrosa del nivel 3.
 * El cactus alterna entre dos estados: normal y con púas.
 *
 * Comportamiento:
 * - Cada 30 segundos le crecen púas que pueden eliminar al jugador.
 * - Después de 30 segundos, vuelve a la normalidad y puede ser recolectado.
 * - Cuando tiene púas, mata al helado si lo toca.
 * - Solo puede recolectarse cuando está sin púas.
 *
 * Otorga 250 puntos al ser recolectado (solo cuando no tiene púas).
 * 
 * @author Camilo Aguirre
 * @version 2025/12/06
 */
public class Cactus extends Fruta {
    private boolean tienePuas;
    
    private int contadorPuas;
    
    /** Tiempo del ciclo de púas (30 segundos = 1800 frames a 60 FPS) */
    private static final int TIEMPO_CICLO_PUAS = 1800;
    
    /**
     * Constructor del Cactus.
     *
     * @param posicion posición inicial del cactus en el tablero
     */
    public Cactus(Posicion posicion) {
        super(posicion, 250);
        tienePuas = false; // Inicia sin púas
        contadorPuas = 0;
        
    }
    
    /**
     * Actualiza el estado del cactus.
     * Controla el ciclo de púas cada 30 segundos.
     */
    @Override
    public void actualizar() {
        contadorPuas++;
        
        // Cambiar estado cada 30 segundos
        if (contadorPuas >= TIEMPO_CICLO_PUAS) {
            tienePuas = !tienePuas; // Alterna entre púas y sin púas
            contadorPuas = 0; // Reinicia el contador
        }
    }
    
    /**
     * Verifica si el cactus tiene púas actualmente.
     * 
     * @return true si tiene púas (peligroso), false si está normal (recolectable)
     */
    public boolean tienePuas() {
        return tienePuas;
    }
    
    /**
     * Establece el estado de las púas del cactus.
     * 
     * @param tienePuas true para activar púas, false para desactivar
     */
    public void setTienePuas(boolean tienePuas) {
        this.tienePuas = tienePuas;
    }
    
    /**
     * Verifica si el cactus puede ser recolectado.
     * Solo puede recolectarse cuando NO tiene púas.
     * 
     * @return true si puede recolectarse (sin púas), false si tiene púas
     */
    public boolean puedeRecolectarse() {
        return !tienePuas;
    }
    
    /**
     * Retorna el tipo de fruta.
     *
     * @return "Cactus"
     */
    @Override
    public String getTipo() {
        return "Cactus";
    }
}
