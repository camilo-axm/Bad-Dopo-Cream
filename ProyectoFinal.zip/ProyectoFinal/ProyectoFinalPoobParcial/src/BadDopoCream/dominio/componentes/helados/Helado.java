
package BadDopoCream.dominio.componentes.helados;

import java.util.ArrayList;
import java.awt.*;
import BadDopoCream.dominio.componentes.Componente;
import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.utilidades.Direccion;
import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.tablero.Celda;
import BadDopoCream.dominio.tablero.BloqueHielo;
import BadDopoCream.dominio.tablero.TipoCelda;

/**
 * Clase abstracta Helado. Clase base para todos los helados 
 *
 * Representa al personaje principal del juego (el jugador)
 * Capacidades del helado:
 * - Moverse en 4 direcciones (arriba, abajo, izquierda, derecha).
 * - Crear bloques de hielo en la dirección hacia donde mira.
 * - Romper bloques de hielo con efecto dominó.
 * Hay 3 tipos: vainilla, chocolate, fresa
 * @author Camilo Aguirre
 * @version 2025/06/12
 */
public abstract class Helado extends Componente {
    protected Direccion direccion;
    
    protected int vidas;
    
    protected int puntaje;
    /** Lista de bloques de hielo creados por el helado */
    protected ArrayList<BloqueHielo> bloquesCreados;
    
    /**
     * Constructor del Helado.
     *
     * @param posicion posición inicial del helado en el tablero
     */
    public Helado(Posicion posicion) {
        super(posicion);
        direccion = new Direccion(Direccion.ABAJO);
        vidas = 3;
        puntaje = 0;
        bloquesCreados = new ArrayList<>();
    }
    
    /**
     * Mueve el helado en una dirección específica.
     *
     * Verifica que:
     * 1. La nueva posición esté dentro de los límites del tablero.
     * 2. La celda destino sea transitable (no sea muro ni bloque de hielo).
     *
     * Si ambas condiciones se cumplen, actualiza la posición
     * del helado en la matriz del tablero.
     *
     * @param dir dirección del movimiento (ARRIBA/ABAJO/IZQUIERDA/DERECHA)
     * @param tablero tablero del juego
     * @return true si se movió exitosamente, false si encontró un obstáculo
     */
    public boolean mover(Direccion dir, Tablero tablero) {
        this.direccion = dir;
        Posicion nuevaPos = dir.mover(posicion);
        
        if (tablero.esPosicionValida(nuevaPos)) {
            Celda celdaDestino = tablero.getCelda(nuevaPos);
            if (celdaDestino != null && celdaDestino.esTransitable()) {
                // Verificar si hay una fogata encendida en la posición destino
                if (tablero.hayFogataEncendidaEn(nuevaPos)) {
                    // El helado muere al tocar una fogata encendida
                    this.activa = false;
                    return false;
                }
                
                // Mover en la matriz
                tablero.moverComponente(posicion, nuevaPos);
                this.posicion = nuevaPos;
                return true;
            }
        }
        return false;
    }
    
    /**
     * Crea bloques de hielo en efecto dominó en la dirección actual del helado.
     *
     * El helado escupe hielo continuamente en la dirección hacia donde mira,
     * creando bloques hasta que encuentre:
     * 1. Un muro o el borde del tablero
     * 2. Un enemigo
     * 3. Otro bloque de hielo
     *
     * Esto permite crear columnas/filas completas de hielo de una sola vez.
     *
     * @param tablero tablero del juego
     * @return true si se creó al menos un bloque, false si no se pudo crear ninguno
     */
    public boolean crearBloque(Tablero tablero) {
        Posicion posActual = direccion.mover(posicion);
        boolean seCreoAlMenosUno = false;
        
        // Continuar creando bloques hasta encontrar un obstáculo
        while (tablero.esPosicionValida(posActual)) {
            Celda celda = tablero.getCelda(posActual);
            
            // Verificar si hay un enemigo en esta posición - si hay enemigo, detenerse
            boolean hayEnemigo = false;
            if (celda != null && celda.tieneComponente()) {
                Componente componente = celda.getComponente();
                if (componente instanceof BadDopoCream.dominio.componentes.enemigos.Enemigo) {
                    hayEnemigo = true;
                }
            }
            
            // Si hay enemigo, detener la creación (no atrapamos enemigos)
            if (hayEnemigo) {
                break;
            }
            
            // Verificar si la celda es transitable y no tiene bloque
            if (celda != null && celda.esTransitable() && !tablero.hayBloqueEn(posActual)) {
                // Crear bloque en esta posición (puede tener fruta, la atrapamos)
                BloqueHielo bloque = new BloqueHielo(posActual);
                tablero.agregarBloque(bloque);
                bloquesCreados.add(bloque);
                seCreoAlMenosUno = true;
                
                // Avanzar a la siguiente posición en la misma dirección
                posActual = direccion.mover(posActual);
            } else {
                // Si encontramos un obstáculo, detenemos la creación
                break;
            }
        }
        
        return seCreoAlMenosUno;
    }
    
    /**
     * Rompe bloques de hielo con efecto dominó.
     *
     * Comportamiento:
     * Avanza en la dirección actual del helado rompiendo todos
     * los bloques de hielo consecutivos que encuentre.
     * 
     * Se detiene cuando encuentra una celda vacía, un muro
     * o el límite del tablero. Puede destruir varios bloques
     * de una vez.
     *
     * @param tablero tablero del juego
     */
    public void romperBloques(Tablero tablero) {
        Posicion posActual = direccion.mover(posicion);
        
        while (tablero.esPosicionValida(posActual) && tablero.hayBloqueEn(posActual)) {
            tablero.eliminarBloqueEn(posActual);
            posActual = direccion.mover(posActual);
        }
    }
    
    /**
     * Obtiene la dirección actual del helado.
     *
     * @return dirección hacia donde mira el helado
     */
    public Direccion getDireccion() {
        return direccion;
    }
    
    /**
     * Obtiene el puntaje acumulado.
     *
     * @return puntaje actual del helado
     */
    public int getPuntaje() {
        return puntaje;
    }
    
    /**
     * Añade puntos al puntaje del helado.
     * Se llama cuando recolecta una fruta.
     *
     * @param puntos cantidad de puntos a agregar
     */
    public void agregarPuntaje(int puntos) {
        puntaje = puntaje + puntos;
    }
    
    /**
     * Actualiza el estado del helado.
     * Lógica básica de actualización en cada frame.
     */
    @Override
    public void actualizar() {
        // Lógica de actualización básica
    }
    
    /**
     * Obtiene el color del helado.
     *
     * @return cadena con el color (para renderizado)
     */
    public abstract String getColor();
    
}

