package BadDopoCream.dominio.utilidades;

/**
 * Clase Temporizador - Controla el tiempo límite de 3 minutos por nivel.
 * Si el tiempo se agota antes de recolectar todas las frutas, el nivel se pierde.
 * Funciona con frames (60 frames = 1 segundo), asumiendo 60 FPS.
 * @author Camilo Aguirre
 * @version 2025/06/12
 */
public class Temporizador {
    private int tiempoRestante; // en frames (60 frames = 1 segundo)
    private static final int TIEMPO_MAXIMO = 180 * 60; // 3 minutos en frames
    private boolean corriendo;
    
    /**
     * Constructor del Temporizador
     */
    public Temporizador() {
        tiempoRestante = TIEMPO_MAXIMO;
        corriendo = false;
    }
    
    /**
     * Inicia el temporizador
     */
    public void iniciar() {
        corriendo = true;
    }
    
    /**
     * Pausa el temporizador
     */
    public void pausar() {
        corriendo = false;
    }
    
    /**
     * Reinicia el temporizador
     */
    public void reiniciar() {
        tiempoRestante = TIEMPO_MAXIMO;
        corriendo = false;
    }
    
    /**
     * Actualiza el temporizador (llamar cada frame)
     */
    public void actualizar() {
        if (corriendo && tiempoRestante > 0) {
            tiempoRestante--;
        }
    }
    
    /**
     * Obtiene el tiempo restante en segundos
     * @return segundos restantes
     */
    public int getTiempoRestante() {
        return tiempoRestante / 60;
    }
    
    /**
     * Obtiene el tiempo formateado como MM:SS
     * @return tiempo en formato MM:SS
     */
    public String getTiempoFormateado() {
        int segundosTotal = tiempoRestante / 60;
        int minutos = segundosTotal / 60;
        int segundos = segundosTotal % 60;
        return String.format("%02d:%02d", minutos, segundos);
    }
    
    /**
     * Verifica si el tiempo se agotó
     * @return true si no queda tiempo
     */
    public boolean seAcaboElTiempo() {
        return tiempoRestante <= 0;
    }
}



