package BadDopoCream.dominio.utilidades;

/**
 * Clase EstadoJuego - Representa el estado actual del juego.
 * Estados posibles: MENU (menú principal), JUGANDO (nivel en curso),
 * PAUSADO (juego pausado), VICTORIA (nivel completado),
 * DERROTA (nivel perdido), GAME_OVER (juego terminado).
 * @author Camilo Aguirre
 * @version 2025/06/12
 */

public class EstadoJuego {
    public static final int MENU = 0;           // En el menú principal
    public static final int JUGANDO = 1;        // Jugando activamente
    public static final int PAUSADO = 2;        // Juego pausado
    public static final int VICTORIA = 3;       // Nivel completado
    public static final int DERROTA = 4;        // Nivel perdido
    public static final int GAME_OVER = 5;      // Fin del juego 
    
    private int estado;
    
    /**
     * Constructor de EstadoJuego
     * @param estado estado inicial
     */
    public EstadoJuego(int estado) {
        this.estado = estado;
    }
    
    /**
     * Obtiene el estado actual
     * @return estado actual
     */
    public int getEstado() {
        return estado;
    }
    
    /**
     * Establece el estado del juego
     * @param estado nuevo estado
     */
    public void setEstado(int estado) {
        this.estado = estado;
    }
}

