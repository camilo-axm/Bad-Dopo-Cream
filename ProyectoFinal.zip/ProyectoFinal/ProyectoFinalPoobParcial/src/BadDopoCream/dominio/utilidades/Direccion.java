package BadDopoCream.dominio.utilidades;

/**
 * Clase que representa las direcciones de movimiento en el juego (Arriba, Abajo, Izquierda, Derecha).
 * Cada dirección tiene asociado un desplazamiento en X y Y (deltaX, deltaY).
 * Por ejemplo: ARRIBA = mover 0 en X, -1 en Y (hacia arriba en la pantalla).
 * @author Camilo Aguirre
 * @version 2025/11/28
 */
public class Direccion {
    // Constantes para representar cada dirección
    public static final int ARRIBA = 0;
    public static final int ABAJO = 1;
    public static final int IZQUIERDA = 2;
    public static final int DERECHA = 3;
    
    private int tipo;
    private int deltaX;
    private int deltaY;
    
    /**
     * Constructor de Direccion
     * @param tipo tipo de dirección (ARRIBA, ABAJO, IZQUIERDA, DERECHA)
     */
    public Direccion(int tipo) {
        this.tipo = tipo;
        calcularDeltas();
    }
    
    /**
     * Calcula los desplazamientos en X y Y según el tipo de dirección.
     * ARRIBA: (0, -1) - no se mueve en X, sube 1 posición en Y
     * ABAJO: (0, 1) - no se mueve en X, baja 1 posición en Y
     * IZQUIERDA: (-1, 0) - se mueve 1 a la izquierda en X, no se mueve en Y
     * DERECHA: (1, 0) - se mueve 1 a la derecha en X, no se mueve en Y
     */
    private void calcularDeltas() {
        if (tipo == ARRIBA) {
            deltaX = 0;
            deltaY = -1;
        } else if (tipo == ABAJO) {
            deltaX = 0;
            deltaY = 1;
        } else if (tipo == IZQUIERDA) {
            deltaX = -1;
            deltaY = 0;
        } else if (tipo == DERECHA) {
            deltaX = 1;
            deltaY = 0;
        }
    }
    
    /**
     * Calcula la nueva posición al moverse en esta dirección
     * @param pos posición actual
     * @return nueva posición
     */
    public Posicion mover(Posicion pos) {
        int nuevaX = pos.getX() + deltaX;
        int nuevaY = pos.getY() + deltaY;
        return new Posicion(nuevaX, nuevaY);
    }

    
    /**
     * Obtiene la dirección opuesta
     * @return dirección opuesta
     */
    public Direccion opuesta() {
        if (tipo == ARRIBA) {
            return new Direccion(ABAJO);
        } else if (tipo == ABAJO) {
            return new Direccion(ARRIBA);
        } else if (tipo == IZQUIERDA) {
            return new Direccion(DERECHA);
        } else if (tipo == DERECHA) {
            return new Direccion(IZQUIERDA);
        } else {
            return new Direccion(tipo);
        }
    }
}

