package BadDopoCream.dominio;

import BadDopoCream.dominio.componentes.enemigos.Enemigo;
import BadDopoCream.dominio.componentes.frutas.Fruta;
import BadDopoCream.dominio.componentes.helados.Helado;
import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.utilidades.Direccion;
import BadDopoCream.dominio.utilidades.Posicion;
import java.util.ArrayList;
import java.util.Random;

// Controla los jugadores automáticos 
// Hay 3 tipos: hungry (busca frutas), fearful (huye de enemigos), expert (balance)
public class MaquinaAutomatica {
    private String perfil;
    private Random random;
    
    // Constructor - crea una máquina con un perfil específico
    public MaquinaAutomatica(String perfil) {
        this.perfil = perfil != null ? perfil : "expert";
        random = new Random();
    }
    
    // Decide hacia dónde moverse según el perfil de la máquina
    public Direccion decidirMovimiento(Helado helado, Tablero tablero) {
        if (helado == null || tablero == null) {
            return null;
        }
        
        // Cada perfil tiene su propia estrategia
        switch (perfil) {
            case "hungry":
                return moverHungry(helado, tablero);
            case "fearful":
                return moverFearful(helado, tablero);
            default:
                return moverExpert(helado, tablero);
        }
    }
    
    // Estrategia Hungry - busca frutas sin importar mucho los enemigos
    private Direccion moverHungry(Helado helado, Tablero tablero) {
        Posicion pos = helado.getPosicion();
        Fruta fruta = frutaCercana(pos, tablero);
        
        if (fruta != null) {
            return moverHacia(pos, fruta.getPosicion(), tablero);
        }
        
        return movimientoSeguro(helado, tablero);
    }
    
    // Estrategia Fearful - huye de enemigos cercanos
    private Direccion moverFearful(Helado helado, Tablero tablero) {
        Posicion pos = helado.getPosicion();
        Enemigo enemigo = enemigoCercano(pos, tablero);
        
        // Si hay enemigo cerca, alejarse
        if (enemigo != null && distancia(pos, enemigo.getPosicion()) < 4) {
            return moverContra(pos, enemigo.getPosicion(), tablero);
        }
        
        // Si no hay peligro, buscar frutas
        Fruta fruta = frutaCercana(pos, tablero);
        if (fruta != null) {
            return moverHacia(pos, fruta.getPosicion(), tablero);
        }
        
        return movimientoSeguro(helado, tablero);
    }
    
    // Estrategia Expert - balance entre recoger frutas y evitar enemigos
    private Direccion moverExpert(Helado helado, Tablero tablero) {
        Posicion pos = helado.getPosicion();
        
        // Alejarse de enemigos muy cercanos
        Enemigo enemigo = enemigoCercano(pos, tablero);
        if (enemigo != null && distancia(pos, enemigo.getPosicion()) < 3) {
            return moverContra(pos, enemigo.getPosicion(), tablero);
        }
        
        // Ir por frutas valiosas si están cerca
        Fruta valiosa = frutaValiosa(pos, tablero);
        if (valiosa != null && distancia(pos, valiosa.getPosicion()) < 6) {
            return moverHacia(pos, valiosa.getPosicion(), tablero);
        }
        
        // Ir por cualquier fruta cercana
        Fruta fruta = frutaCercana(pos, tablero);
        if (fruta != null) {
            return moverHacia(pos, fruta.getPosicion(), tablero);
        }
        
        return movimientoSeguro(helado, tablero);
    }
    
    // Encuentra la fruta más cercana activa
    private Fruta frutaCercana(Posicion origen, Tablero tablero) {
        Fruta mejor = null;
        double distMin = Double.MAX_VALUE;
        
        for (Fruta f : tablero.getFrutas()) {
            if (f.isActiva()) {
                double dist = distancia(origen, f.getPosicion());
                if (dist < distMin) {
                    distMin = dist;
                    mejor = f;
                }
            }
        }
        
        return mejor;
    }
    
    // Encuentra una fruta valiosa (piña o cereza)
    private Fruta frutaValiosa(Posicion origen, Tablero tablero) {
        Fruta mejor = null;
        double distMin = Double.MAX_VALUE;
        
        for (Fruta f : tablero.getFrutas()) {
            if (f.isActiva()) {
                String tipo = f.getClass().getSimpleName();
                if (tipo.equals("Pina") || tipo.equals("Cereza")) {
                    double dist = distancia(origen, f.getPosicion());
                    if (dist < distMin) {
                        distMin = dist;
                        mejor = f;
                    }
                }
            }
        }
        
        return mejor;
    }
    
    // Encuentra el enemigo más cercano activo
    private Enemigo enemigoCercano(Posicion origen, Tablero tablero) {
        Enemigo mejor = null;
        double distMin = Double.MAX_VALUE;
        
        for (Enemigo e : tablero.getEnemigos()) {
            if (e.isActiva()) {
                double dist = distancia(origen, e.getPosicion());
                if (dist < distMin) {
                    distMin = dist;
                    mejor = e;
                }
            }
        }
        
        return mejor;
    }
    
    // Calcula la distancia Manhattan entre dos posiciones
    private double distancia(Posicion a, Posicion b) {
        return Math.abs(a.getX() - b.getX()) + Math.abs(a.getY() - b.getY());
    }
    
    // Calcula dirección para moverse hacia un objetivo
    private Direccion moverHacia(Posicion origen, Posicion destino, Tablero tablero) {
        return moverDireccion(origen, destino, tablero, false);
    }
    
    // Calcula dirección para alejarse de un objetivo
    private Direccion moverContra(Posicion origen, Posicion destino, Tablero tablero) {
        return moverDireccion(origen, destino, tablero, true);
    }
    
    // Método unificado para calcular dirección (hacia o contrario)
    private Direccion moverDireccion(Posicion origen, Posicion destino, Tablero tablero, boolean contrario) {
        int dx = destino.getX() - origen.getX();
        int dy = destino.getY() - origen.getY();
        
        // Si es contrario, invertir las diferencias
        if (contrario) {
            dx = -dx;
            dy = -dy;
        }
        
        ArrayList<Direccion> direcciones = new ArrayList<>();
        
        // Priorizar la dirección con mayor diferencia
        if (Math.abs(dx) > Math.abs(dy)) {
            agregarHorizontal(direcciones, dx);
            agregarVertical(direcciones, dy);
        } else {
            agregarVertical(direcciones, dy);
            agregarHorizontal(direcciones, dx);
        }
        
        // Probar cada dirección en orden de prioridad
        for (Direccion dir : direcciones) {
            if (esValido(origen, dir, tablero)) {
                return dir;
            }
        }
        
        return null;
    }
    
    // Agrega direcciones horizontales según el signo de dx
    private void agregarHorizontal(ArrayList<Direccion> lista, int dx) {
        if (dx > 0) {
            lista.add(new Direccion(Direccion.DERECHA));
        } else if (dx < 0) {
            lista.add(new Direccion(Direccion.IZQUIERDA));
        }
    }
    
    // Agrega direcciones verticales según el signo de dy
    private void agregarVertical(ArrayList<Direccion> lista, int dy) {
        if (dy > 0) {
            lista.add(new Direccion(Direccion.ABAJO));
        } else if (dy < 0) {
            lista.add(new Direccion(Direccion.ARRIBA));
        }
    }
    
    // Encuentra un movimiento seguro aleatorio
    private Direccion movimientoSeguro(Helado helado, Tablero tablero) {
        Posicion pos = helado.getPosicion();
        Direccion[] todas = {
            new Direccion(Direccion.ARRIBA),
            new Direccion(Direccion.ABAJO),
            new Direccion(Direccion.IZQUIERDA),
            new Direccion(Direccion.DERECHA)
        };
        
        // Filtrar solo las direcciones válidas
        ArrayList<Direccion> validas = new ArrayList<>();
        for (Direccion dir : todas) {
            if (esValido(pos, dir, tablero)) {
                validas.add(dir);
            }
        }
        
        // Elegir una dirección válida al azar
        if (!validas.isEmpty()) {
            return validas.get(random.nextInt(validas.size()));
        }
        
        return null;
    }
    
    // Verifica si un movimiento es válido (no hay pared ni enemigo)
    private boolean esValido(Posicion origen, Direccion dir, Tablero tablero) {
        Posicion nueva = dir.mover(origen);
        
        // Verificar límites del tablero
        if (nueva.getX() < 0 || nueva.getX() >= tablero.getColumnas() ||
            nueva.getY() < 0 || nueva.getY() >= tablero.getFilas()) {
            return false;
        }
        
        // Verificar que no sea muro o iglú
        int tipo = tablero.getMatriz()[nueva.getY()][nueva.getX()].getTipo().getTipo();
        if (tipo == 1 || tipo == 3) {
            return false;
        }
        
        // Verificar que no haya enemigo en esa posición
        for (Enemigo enemigo : tablero.getEnemigos()) {
            if (enemigo.isActiva() && enemigo.getPosicion().equals(nueva)) {
                return false;
            }
        }
        
        return true;
    }
}