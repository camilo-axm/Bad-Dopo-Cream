package BadDopoCream.dominio;

import BadDopoCream.dominio.utilidades.Posicion;

/**
 * Clase Nivel3 - Configuración del tercer nivel del juego.
 * Nivel difícil: 10 Cactus, 1 Maceta, 1 Narval
 * Obstáculos: 9 Fogatas distribuidas por el tablero
 * 
 * @author Camilo Aguirre
 * @version 2025/12/06
 */
public class Nivel3 extends Nivel {
    
    /**
     * Constructor del Nivel 3
     */
    public Nivel3() {
        super(3);
        configurar();
    }
    
    /**
     * Configura las características específicas del nivel 3
     */
    private void configurar() {
        // Posición inicial del helado
        setPosicionInicialHelado(new Posicion(7, 9));
        
        // Agregar 10 Cactus
        for (int i = 0; i < 10; i++) {
            agregarFruta("Cactus");
        }
        
        // Agregar 1 Maceta y 1 Narval
        agregarEnemigo("Maceta", 2, 2);
        agregarEnemigo("Narval", 12, 9);
        
        // Agregar 9 Fogatas distribuidas estratégicamente
        // Fila superior
        agregarObstaculo("Fogata", 3, 3);
        agregarObstaculo("Fogata", 7, 2);
        agregarObstaculo("Fogata", 11, 3);
        
        // Fila media
        agregarObstaculo("Fogata", 2, 6);
        agregarObstaculo("Fogata", 12, 6);
        
        // Fila inferior
        agregarObstaculo("Fogata", 3, 9);
        agregarObstaculo("Fogata", 7, 10);
        agregarObstaculo("Fogata", 11, 9);
        
        // Fogata adicional en posición estratégica
        agregarObstaculo("Fogata", 7, 6);
    }
}
