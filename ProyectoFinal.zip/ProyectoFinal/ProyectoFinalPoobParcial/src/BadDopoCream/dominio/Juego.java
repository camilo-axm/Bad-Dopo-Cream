package BadDopoCream.dominio;

import BadDopoCream.dominio.componentes.helados.Helado;
import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.utilidades.Direccion;
import BadDopoCream.dominio.utilidades.EstadoJuego;
import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.utilidades.Temporizador;

/**
 * Clase Juego - es la clase orquestadora principal del juego.
 * Coordina Tablero, Nivel, Temporizador, Estado.
 * Es la responsable de iniciar el juego, actualizar lógica, verificar victoria/derrota,
 * procesar acciones del jugador (mover, crear/romper bloques, pausar).
 * Es el punto de entrada principal para el Controlador.
 * @author Camilo Aguirre
 * @version 2025/12/02
 */
public class Juego {
    private Tablero tablero;
    private Nivel nivelActual;
    private Temporizador temporizador;
    private EstadoJuego estado;
    private int numeroNivel;
    private String tipoHelado1;
    private String tipoHelado2;
    private String modoJuego; // "Player", "PvsP", "PvsM", "MvsM"
    private String perfilMaquina1;
    private String perfilMaquina2;
    private boolean helado1Vivo;
    private boolean helado2Vivo;
    private MaquinaAutomatica maquina1; // Para PvsM y MvsM
    private MaquinaAutomatica maquina2; // Para MvsM
    private int contadorFramesMaquina; // Para controlar la velocidad de la IA
    private static final int FRAMES_POR_MOVIMIENTO_AUTO = 15; //se mueve cada 15 frames
    
    /**
     * Constructor del Juego
     */
    public Juego() {
        estado = new EstadoJuego(EstadoJuego.MENU);
        temporizador = new Temporizador();
        numeroNivel = 1;
    }
    
    /**
     * Inicia un nuevo juego
     * @param numeroNivel nivel a jugar (dentro de los requisitos son 1, 2, 3)
     * @param tipoHelado1 tipo de helado del jugador 1
     * @param tipoHelado2 tipo de helado del jugador 2
     * @param modoJuego modo de juego ("Player", "PvsP", "PvsM", "MvsM")
     * @param perfilMaquina1 perfil de la máquina 1 (para PvsM y MvsM)
     * @param perfilMaquina2 perfil de la máquina 2 (para MvsM)
     */
    public void iniciarJuego(int numeroNivel, String tipoHelado1, String tipoHelado2, String modoJuego, 
                            String perfilMaquina1, String perfilMaquina2) {
        System.out.println("Juego.iniciarJuego() - Nivel: " + numeroNivel + 
                          ", Helado1: " + tipoHelado1 + ", Helado2: " + tipoHelado2 + 
                          ", Modo: " + modoJuego + ", Perfil1: " + perfilMaquina1 + 
                          ", Perfil2: " + perfilMaquina2);
        
        this.numeroNivel = numeroNivel;
        this.tipoHelado1 = tipoHelado1;
        this.tipoHelado2 = tipoHelado2;
        this.modoJuego = modoJuego;
        this.perfilMaquina1 = perfilMaquina1;
        this.perfilMaquina2 = perfilMaquina2;
        
        // Crear el nivel correspondiente
        if (numeroNivel == 1) {
            nivelActual = new Nivel1();
        } else if (numeroNivel == 2) {
            nivelActual = new Nivel2();
        } else if (numeroNivel == 3) {
            nivelActual = new Nivel3();
        } else {
            nivelActual = new Nivel1(); // Por defecto nivel 1
        }
        
        // Crear el tablero con la configuración del nivel
        tablero = nivelActual.crearTablero(tipoHelado1, tipoHelado2, modoJuego);
        
        System.out.println("Tablero creado - Filas: " + tablero.getFilas() + ", Columnas: " + tablero.getColumnas());
        System.out.println("Frutas en tablero: " + tablero.getFrutas().size());
        System.out.println("Enemigos en tablero: " + tablero.getEnemigos().size());
        
        // Inicializar estados de vida de los helados
        helado1Vivo = (tablero.getHelado() != null);
        helado2Vivo = (tablero.getHelado2() != null);
        
        // Inicializar máquinas automáticas según el modo
        maquina1 = null;
        maquina2 = null;
        contadorFramesMaquina = 0;
        
        if ("PvsM".equals(modoJuego)) {
            // En PvsM, el jugador 2 es controlado por máquina
            maquina2 = new MaquinaAutomatica(perfilMaquina1);
            System.out.println("Máquina automática creada para J2 con perfil: " + perfilMaquina1);
        } else if ("MvsM".equals(modoJuego)) {
            // En MvsM, ambos jugadores son máquinas
            maquina1 = new MaquinaAutomatica(perfilMaquina1);
            maquina2 = new MaquinaAutomatica(perfilMaquina2);
            System.out.println("Máquinas automáticas creadas - J1: " + perfilMaquina1 + ", J2: " + perfilMaquina2);
        }
        
        // Iniciar el temporizador
        temporizador.reiniciar();
        temporizador.iniciar();
        
        estado.setEstado(EstadoJuego.JUGANDO);
        System.out.println("Estado del juego establecido a JUGANDO");
    }
    
    /**
     * Actualiza el estado del juego en cada frame
     */
    public void actualizar() {
        if (estado.getEstado() != EstadoJuego.JUGANDO){        
        return;
        }
        // Actualiza el temporizador
        temporizador.actualizar();
        // Actualiza el tablero (enemigos, frutas)
        tablero.actualizar();
        
        // Actualizar movimientos de las máquinas automáticas
        actualizarMaquinas();
        
        // Verifica la condicion del juego de victoria/derrota
        verificarEstadoJuego();
    }
    
    /**
     * Actualiza los movimientos de las máquinas automáticas
     */
    private void actualizarMaquinas() {
        contadorFramesMaquina++;
        
        // Las máquinas se mueven cada cierto número de frames
        if (contadorFramesMaquina >= FRAMES_POR_MOVIMIENTO_AUTO) {
            contadorFramesMaquina = 0;
            
            // Mover máquina 1 (en modo MvsM)
            if (maquina1 != null && helado1Vivo && tablero.getHelado() != null) {
                Direccion direccion = maquina1.decidirMovimiento(tablero.getHelado(), tablero);
                if (direccion != null) {
                    moverHelado(direccion);
                }
            }
            
            // Mover máquina 2 (en modos PvsM y MvsM)
            if (maquina2 != null && helado2Vivo && tablero.getHelado2() != null) {
                Direccion direccion = maquina2.decidirMovimiento(tablero.getHelado2(), tablero);
                if (direccion != null) {
                    moverHelado2(direccion);
                }
            }
        }
    }
    
    /**
     * Verifica las condiciones de victoria o derrota de cada frame.
     * Derrota si: Se acaba el tiempo (3 minutos), o ambos helados mueren.
     * Victoria si: Se recolectan todas las frutas.
     */
    private void verificarEstadoJuego() {
        // Verifica la derrota por tiempo
        if (temporizador.seAcaboElTiempo()) {
            estado.setEstado(EstadoJuego.DERROTA);
            return;
        }
        
        // Verificar colisiones individuales de cada helado
        verificarColisionesIndividuales();
        
        // El juego termina solo si AMBOS jugadores están muertos (en modos multijugador)
        if ("Player".equals(modoJuego)) {
            // Modo un jugador: termina si el único helado muere
            if (!helado1Vivo) {
                estado.setEstado(EstadoJuego.DERROTA);
                return;
            }
        } else {
            // Modos multijugador: termina solo si ambos mueren
            if (!helado1Vivo && !helado2Vivo) {
                estado.setEstado(EstadoJuego.DERROTA);
                return;
            }
        }
        
        // Verifica la victoria si todas las frutas fueron recolectadas
        if (tablero.contarFrutasActivas() == 0) {
            estado.setEstado(EstadoJuego.VICTORIA);
            temporizador.pausar();
        }
    }
    
    /**
     * Verifica colisiones con enemigos para cada helado individualmente
     */
    private void verificarColisionesIndividuales() {
        // Verificar helado 1
        if (helado1Vivo && tablero.getHelado() != null) {
            Posicion posHelado1 = tablero.getHelado().getPosicion();
            for (BadDopoCream.dominio.componentes.enemigos.Enemigo enemigo : tablero.getEnemigos()) {
                if (enemigo.isActiva() && enemigo.getPosicion().equals(posHelado1)) {
                    helado1Vivo = false;
                    System.out.println("¡Jugador 1 ha muerto!");
                    break;
                }
            }
        }
        
        // Verificar helado 2
        if (helado2Vivo && tablero.getHelado2() != null) {
            Posicion posHelado2 = tablero.getHelado2().getPosicion();
            for (BadDopoCream.dominio.componentes.enemigos.Enemigo enemigo : tablero.getEnemigos()) {
                if (enemigo.isActiva() && enemigo.getPosicion().equals(posHelado2)) {
                    helado2Vivo = false;
                    System.out.println("¡Jugador 2 ha muerto!");
                    break;
                }
            }
        }
    }
    
    /**
     * Mueve el helado en una dirección (jugador 1)
     * @param direccion dirección de movimiento
     */
    public void moverHelado(Direccion direccion) {
        if (estado.getEstado() == EstadoJuego.JUGANDO && tablero != null && helado1Vivo) {
            Helado helado = tablero.getHelado();
            if (helado != null) {
                helado.mover(direccion, tablero);
            }
        }
    }
    
    /**
     * Mueve el helado 2 en una dirección (jugador 2)
     * @param direccion dirección de movimiento
     */
    public void moverHelado2(Direccion direccion) {
        if (estado.getEstado() == EstadoJuego.JUGANDO && tablero != null && helado2Vivo) {
            Helado helado2 = tablero.getHelado2();
            if (helado2 != null) {
                helado2.mover(direccion, tablero);
            }
        }
    }
    
    /**
     * Ejecuta la acción de bloque con la tecla ESPACIO (jugador 1).
     * Si hay un bloque en la dirección actual rompe los bloques en efecto dominó.
     * Si no hay bloque crea un bloque nuevo.
     */
    public void accionBloque() {
        if (estado.getEstado() == EstadoJuego.JUGANDO && tablero != null && helado1Vivo) {
            Helado helado = tablero.getHelado();
            if (helado != null) {
                Posicion posBloque = helado.getDireccion().mover(helado.getPosicion());
                
                if (tablero.hayBloqueEn(posBloque)) {
                    // Romper bloques
                    helado.romperBloques(tablero);
                } else {
                    // Crear bloque
                    helado.crearBloque(tablero);
                }
            }
        }
    }
    
    /**
     * Ejecuta la acción de bloque (jugador 2).
     * Si hay un bloque en la dirección actual rompe los bloques en efecto dominó.
     * Si no hay bloque crea un bloque nuevo.
     */
    public void accionBloque2() {
        if (estado.getEstado() == EstadoJuego.JUGANDO && tablero != null && helado2Vivo) {
            Helado helado2 = tablero.getHelado2();
            if (helado2 != null) {
                Posicion posBloque = helado2.getDireccion().mover(helado2.getPosicion());
                
                if (tablero.hayBloqueEn(posBloque)) {
                    // Romper bloques
                    helado2.romperBloques(tablero);
                } else {
                    // Crear bloque
                    helado2.crearBloque(tablero);
                }
            }
        }
    }
    
    /**
     * Pausa o reanuda el juego
     */
    public void pausa() {
        if (estado.getEstado() == EstadoJuego.JUGANDO) {
            estado.setEstado(EstadoJuego.PAUSADO);
            temporizador.pausar();
            System.out.println("Juego pausado");
        } else if (estado.getEstado() == EstadoJuego.PAUSADO) {
            estado.setEstado(EstadoJuego.JUGANDO);
            temporizador.iniciar();
            System.out.println("Juego reanudado");
        }
    }
    
    /**
     * Reinicia el nivel actual
     */
    public void reiniciarNivel() {
        iniciarJuego(numeroNivel, tipoHelado1, tipoHelado2, modoJuego, perfilMaquina1, perfilMaquina2);
    }
    
    /**
     * Avanza al siguiente nivel
     */
    public void siguienteNivel() {
        if (numeroNivel < 3) {
            iniciarJuego(numeroNivel + 1, tipoHelado1, tipoHelado2, modoJuego, perfilMaquina1, perfilMaquina2);
        } else {
            estado.setEstado(EstadoJuego.GAME_OVER);
        }
    }
    
    /**
     * Vuelve al menú principal
     */
    public void volverAlMenu() {
        estado.setEstado(EstadoJuego.MENU);
        temporizador.reiniciar();
    }
    
    // Getters
    
    public Tablero getTablero() {
        return tablero;
    }
    
    public EstadoJuego getEstado() {
        return estado;
    }
    
    public Temporizador getTemporizador() {
        return temporizador;
    }
    
    public int getNumeroNivel() {
        return numeroNivel;
    }
    
    public String getModoJuego() {
        return modoJuego;
    }
    
    public int getPuntaje() {
        if (tablero != null && tablero.getHelado() != null) {
            return tablero.getHelado().getPuntaje();
        }
        return 0;
    }
    
    public int getPuntaje2() {
        if (tablero != null && tablero.getHelado2() != null) {
            return tablero.getHelado2().getPuntaje();
        }
        return 0;
    }
    
    public int getFrutasRestantes() {
        if (tablero != null) {
            return tablero.contarFrutasActivas();
        }
        return 0;
    }
    
    public boolean isHelado1Vivo() {
        return helado1Vivo;
    }
    
    public boolean isHelado2Vivo() {
        return helado2Vivo;
    }
    
    /**
     * Obtiene el jugador ganador basado en el puntaje
     * @return 1 si gana jugador 1, 2 si gana jugador 2, 0 si empate
     */
    public int getJugadorGanador() {
        int puntaje1 = getPuntaje();
        int puntaje2 = getPuntaje2();
        
        if (puntaje1 > puntaje2) {
            return 1;
        } else if (puntaje2 > puntaje1) {
            return 2;
        } else {
            return 0; // Empate
        }
    }
}

