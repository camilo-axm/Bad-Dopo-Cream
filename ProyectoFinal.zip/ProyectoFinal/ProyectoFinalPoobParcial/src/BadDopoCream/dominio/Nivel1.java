package BadDopoCream.dominio;

import BadDopoCream.dominio.utilidades.Posicion;

/**
 * Clase Nivel1 - Configuración del primer nivel del juego.
 * Nivel fácil: 8 Uvas, 8 Plátanos, 1 Troll, 1 Maceta
 * Sin obstáculos.
 * 
 * @author Camilo Aguirre
 * @version 2025/12/06
 */
public class Nivel1 extends Nivel {
    
    /**
     * Constructor del Nivel 1
     */
    public Nivel1() {
        super(1);
        configurar();
    }
    
    /**
     * Configura las características específicas del nivel 1
     */
    private void configurar() {
        // Posición inicial del helado
        setPosicionInicialHelado(new Posicion(7, 9));
        
        // Agregar 8 Uvas
        for (int i = 0; i < 8; i++) {
            agregarFruta("Uva");
        }
        
        // Agregar 8 Plátanos
        for (int i = 0; i < 8; i++) {
            agregarFruta("Platano");
        }
        
        // Agregar 1 Troll y 1 Maceta
        agregarEnemigo("Troll", 2, 2);
        agregarEnemigo("Maceta", 12, 9);
        
        // Sin obstáculos en nivel 1
    }
}
