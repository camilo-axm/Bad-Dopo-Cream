package BadDopoCream.dominio;

import BadDopoCream.dominio.utilidades.Posicion;

/**
 * Clase Nivel2 - Configuración del segundo nivel del juego.
 * Nivel medio: 8 Cerezas, 8 Piñas, 1 Troll, 1 Calamar Naranja
 * Obstáculos: 3 filas de Baldosas Calientes (8 baldosas por fila)
 * 
 * @author Camilo Aguirre
 * @version 2025/12/06
 */
public class Nivel2 extends Nivel {
    
    /**
     * Constructor del Nivel 2
     */
    public Nivel2() {
        super(2);
        configurar();
    }
    
    /**
     * Configura las características específicas del nivel 2
     */
    private void configurar() {
        // Posición inicial del helado
        setPosicionInicialHelado(new Posicion(7, 9));
        
        // Agregar 8 Cerezas
        for (int i = 0; i < 8; i++) {
            agregarFruta("Cereza");
        }
        
        // Agregar 8 Piñas
        for (int i = 0; i < 8; i++) {
            agregarFruta("Pina");
        }
        // Agregar 1 Troll y 1 Calamar Naranja
        agregarEnemigo("Troll", 2, 2);
        agregarEnemigo("CalamarNaranja", 12, 9);
        
        // Agregar 3 filas de Baldosas Calientes (8 baldosas cada fila)
        // Fila 1 (fila 3 del tablero)
        for (int col = 3; col < 11; col++) {
            agregarObstaculo("BaldosaCaliente", col, 3);
        }
        
        // Fila 2 (fila 6 del tablero - centro)
        for (int col = 3; col < 11; col++) {
            agregarObstaculo("BaldosaCaliente", col, 6);
        }
        
        // Fila 3 (fila 9 del tablero)
        for (int col = 3; col < 11; col++) {
            agregarObstaculo("BaldosaCaliente", col, 9);
        }
    }
}
